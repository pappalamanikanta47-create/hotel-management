import test from 'node:test';
import assert from 'node:assert/strict';
import {
  computeDefaultDueDate,
  isRecordOverdue,
  stripAnsi,
  validateEstimatedCost,
  validateRequestForm,
  validateRoomNumber,
  type MaintenanceRequest,
  type RequestFormValues,
} from './trackerLogic';

test('validateRoomNumber accepts standard formats and rejects malformed input', () => {
  assert.equal(validateRoomNumber('b-204'), null);
  assert.equal(validateRoomNumber('305'), null);
  assert.notEqual(validateRoomNumber(''), null);
  assert.notEqual(validateRoomNumber('ROOM!!'), null);
});

test('validateEstimatedCost enforces finite bounds between 0 and 50000', () => {
  assert.equal(validateEstimatedCost('0'), null);
  assert.equal(validateEstimatedCost('450.75'), null);
  assert.notEqual(validateEstimatedCost('-12'), null);
  assert.notEqual(validateEstimatedCost('abc'), null);
  assert.notEqual(validateEstimatedCost('75000'), null);
});

test('validateRequestForm catches missing fields and inverted due dates', () => {
  const invalid: RequestFormValues = {
    hostel_block: 'Block B',
    room_number: 'B-204',
    category: 'Plumbing',
    priority: 'High',
    description: 'short',
    reporter_name: '123',
    reported_date: '2026-11-20',
    due_date: '2026-11-18',
    estimated_cost: '-5',
    assigned_staff: '',
    notes: '',
  };
  const errors = validateRequestForm(invalid);
  assert.ok(errors.description);
  assert.ok(errors.reporter_name);
  assert.ok(errors.due_date);
  assert.ok(errors.estimated_cost);
});

test('computeDefaultDueDate applies SLA days by priority', () => {
  assert.equal(computeDefaultDueDate('2026-11-20', 'Critical'), '2026-11-21');
  assert.equal(computeDefaultDueDate('2026-11-20', 'High'), '2026-11-23');
  assert.equal(computeDefaultDueDate('2026-11-20', 'Medium'), '2026-11-27');
});

test('isRecordOverdue ignores Resolved items and flags past-due open items', () => {
  const base: MaintenanceRequest = {
    request_id: 'HMT-2026-0001',
    hostel_block: 'Block A',
    room_number: 'A-101',
    category: 'Plumbing',
    priority: 'High',
    status: 'Pending',
    description: 'Water tap dripping continuously',
    reporter_name: 'Aarav Sharma',
    reported_date: '2026-11-10',
    due_date: '2026-11-15',
    estimated_cost: 50,
    resolved_date: null,
    assigned_staff: 'R. Nair',
    notes: '',
  };
  assert.equal(isRecordOverdue(base, '2026-11-20'), true);
  assert.equal(isRecordOverdue({ ...base, status: 'Resolved' }, '2026-11-20'), false);
});

test('stripAnsi removes terminal color escape sequences cleanly', () => {
  assert.equal(stripAnsi('\x1b[31mOverdue\x1b[0m'), 'Overdue');
});
