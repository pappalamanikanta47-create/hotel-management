export const HOSTEL_BLOCKS = [
  'Block A',
  'Block B',
  'Block C',
  'Block D',
  'North Wing',
  'South Wing',
] as const;

export const CATEGORIES = [
  'Plumbing',
  'Electrical',
  'Carpentry',
  'HVAC',
  'Sanitation',
  'Internet & Network',
  'Structural',
  'General',
] as const;

export const PRIORITIES = ['Low', 'Medium', 'High', 'Critical'] as const;

export const STATUSES = ['Pending', 'In Progress', 'Resolved'] as const;

export const SLA_DAYS_BY_PRIORITY: Record<string, number> = {
  Critical: 1,
  High: 3,
  Medium: 7,
  Low: 14,
};

export interface MaintenanceRequest {
  request_id: string;
  hostel_block: string;
  room_number: string;
  category: string;
  priority: string;
  status: string;
  description: string;
  reporter_name: string;
  reported_date: string;
  due_date: string;
  estimated_cost: number;
  resolved_date: string | null;
  assigned_staff: string;
  notes: string;
}

export interface ThresholdWarning {
  code: string;
  severity: 'Critical' | 'Warning';
  request_id: string;
  title: string;
  detail: string;
}

export interface CategoryStats {
  total: number;
  pending: number;
  in_progress: number;
  resolved: number;
  open: number;
  overdue: number;
  cost: number;
}

export interface BlockStats {
  total: number;
  open: number;
  overdue: number;
  resolved: number;
  pending_cost: number;
}

export interface MonthlyTrendItem {
  month: string;
  reported: number;
  resolved: number;
  open: number;
}

export interface ExecutiveSummary {
  generated_at: string;
  reference_date: string;
  total_requests: number;
  pending_count: number;
  in_progress_count: number;
  resolved_count: number;
  open_count: number;
  overdue_count: number;
  critical_open_count: number;
  resolution_rate_pct: number;
  avg_open_age_days: number;
  avg_resolution_days: number;
  total_estimated_cost: number;
  pending_estimated_cost: number;
  by_category: Record<string, CategoryStats>;
  by_block: Record<string, BlockStats>;
  by_priority: Record<string, number>;
  monthly_trend: MonthlyTrendItem[];
  warnings: ThresholdWarning[];
}

export interface ImportRowError {
  row_number: number;
  raw_row: Record<string, string>;
  errors: string[];
}

export interface BulkImportResult {
  total_rows: number;
  imported_count: number;
  skipped_count: number;
  imported_ids: string[];
  error_log: ImportRowError[];
}

export interface RequestFormValues {
  hostel_block: string;
  room_number: string;
  category: string;
  priority: string;
  description: string;
  reporter_name: string;
  reported_date: string;
  due_date: string;
  estimated_cost: string;
  assigned_staff: string;
  notes: string;
}

const ROOM_REGEX = /^(?:[A-Z]{1,3}-?)?\d{2,4}[A-Z]?$/;
const NAME_REGEX = /^[A-Za-z][A-Za-z\s.'-]{1,59}$/;
const ISO_DATE_REGEX = /^\d{4}-\d{2}-\d{2}$/;

export function sanitizeText(value: string): string {
  return value.replace(/[\x00-\x1f\x7f]+/g, ' ').replace(/\s+/g, ' ').trim();
}

export function validateRoomNumber(raw: string): string | null {
  const normalized = sanitizeText(raw).toUpperCase();
  if (!normalized) return 'Room number is required (e.g., B-204 or 305).';
  if (!ROOM_REGEX.test(normalized)) {
    return 'Room number must be 2-4 digits with optional block prefix (e.g., B-204).';
  }
  return null;
}

export function validateEstimatedCost(raw: string): string | null {
  const cleaned = raw.replace(/[$,\s]/g, '');
  if (!cleaned) return 'Estimated cost is required (enter 0 if no material cost).';
  const num = Number(cleaned);
  if (!Number.isFinite(num)) return 'Estimated cost must be a valid numeric value.';
  if (num < 0 || num > 50000) return 'Estimated cost must be between $0.00 and $50,000.00.';
  return null;
}

export function isValidIsoDate(raw: string): boolean {
  if (!ISO_DATE_REGEX.test(raw)) return false;
  const [y, m, d] = raw.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return (
    dt.getUTCFullYear() === y &&
    dt.getUTCMonth() === m - 1 &&
    dt.getUTCDate() === d
  );
}

export function validateRequestForm(values: RequestFormValues): Record<string, string> {
  const errors: Record<string, string> = {};

  if (!HOSTEL_BLOCKS.includes(values.hostel_block as (typeof HOSTEL_BLOCKS)[number])) {
    errors.hostel_block = 'Select a valid hostel block.';
  }

  const roomErr = validateRoomNumber(values.room_number);
  if (roomErr) errors.room_number = roomErr;

  if (!CATEGORIES.includes(values.category as (typeof CATEGORIES)[number])) {
    errors.category = 'Select a valid maintenance category.';
  }

  if (!PRIORITIES.includes(values.priority as (typeof PRIORITIES)[number])) {
    errors.priority = 'Select a valid priority level.';
  }

  const desc = sanitizeText(values.description);
  if (!desc) {
    errors.description = 'Issue description is required.';
  } else if (desc.length < 8) {
    errors.description = 'Description must be at least 8 characters long.';
  } else if (desc.length > 280) {
    errors.description = 'Description cannot exceed 280 characters.';
  }

  const reporter = sanitizeText(values.reporter_name);
  if (!reporter) {
    errors.reporter_name = 'Reporter name is required.';
  } else if (!NAME_REGEX.test(reporter)) {
    errors.reporter_name =
      'Reporter name must start with a letter and contain 2-60 valid name characters.';
  }

  if (!isValidIsoDate(values.reported_date)) {
    errors.reported_date = 'Reported date must use YYYY-MM-DD format.';
  }

  if (!isValidIsoDate(values.due_date)) {
    errors.due_date = 'Due date must use YYYY-MM-DD format.';
  } else if (
    isValidIsoDate(values.reported_date) &&
    values.due_date < values.reported_date
  ) {
    errors.due_date = 'Due date cannot be earlier than reported date.';
  }

  const costErr = validateEstimatedCost(values.estimated_cost);
  if (costErr) errors.estimated_cost = costErr;

  return errors;
}

export function computeDefaultDueDate(reportedDate: string, priority: string): string {
  if (!isValidIsoDate(reportedDate)) return reportedDate;
  const slaDays = SLA_DAYS_BY_PRIORITY[priority] ?? 7;
  const [y, m, d] = reportedDate.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d + slaDays));
  return dt.toISOString().slice(0, 10);
}

export function isRecordOverdue(record: MaintenanceRequest, referenceDate: string): boolean {
  if (record.status === 'Resolved') return false;
  if (!record.due_date || !referenceDate) return false;
  return record.due_date < referenceDate;
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

export function stripAnsi(text: string): string {
  return text.replace(/\x1b\[[0-9;]*m/g, '');
}
