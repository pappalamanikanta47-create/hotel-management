import { AlertTriangle, ArrowRight, CheckCircle2, Clock } from 'lucide-react';
import {
  formatCurrency,
  type ExecutiveSummary,
} from '../utils/trackerLogic';

interface OverviewViewProps {
  summary: ExecutiveSummary | null;
  loading: boolean;
  onFilterOverdue: () => void;
  onFilterBlock: (block: string) => void;
  onFilterCategory: (category: string) => void;
  onInspectTicket: (requestId: string) => void;
}

export function OverviewView({
  summary,
  loading,
  onFilterOverdue,
  onFilterBlock,
  onFilterCategory,
  onInspectTicket,
}: OverviewViewProps) {
  if (loading && !summary) {
    return (
      <div className="space-y-6" aria-busy="true" aria-label="Loading summary">
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((idx) => (
            <div
              key={idx}
              className="h-28 bg-white border border-slate-200 rounded-lg animate-pulse"
            />
          ))}
        </div>
        <div className="h-72 bg-white border border-slate-200 rounded-lg animate-pulse" />
      </div>
    );
  }

  if (!summary) {
    return (
      <div className="bg-white border border-slate-200 rounded-lg p-8 text-center">
        <p className="text-sm text-slate-600">
          Executive summary data is not available.
        </p>
      </div>
    );
  }

  const categoryEntries = Object.entries(summary.by_category);
  const maxCategoryTotal = Math.max(
    1,
    ...categoryEntries.map(([, stats]) => stats.total)
  );
  const blockEntries = Object.entries(summary.by_block);

  return (
    <div className="space-y-6">
      {/* 4-Column KPI Strip */}
      <section aria-label="Key Performance Indicators">
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
          <div className="bg-white border border-slate-200 rounded-lg p-5">
            <div className="text-xs font-medium text-slate-500">
              Total Maintenance Requests
            </div>
            <div className="mt-2 font-mono text-2xl font-semibold text-slate-900 tabular-nums">
              {summary.total_requests}
            </div>
            <div className="mt-2 text-xs text-slate-500 tabular-nums">
              {summary.resolved_count} resolved · {summary.resolution_rate_pct.toFixed(1)}% rate
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-lg p-5">
            <div className="text-xs font-medium text-slate-500">
              Unresolved Issues
            </div>
            <div className="mt-2 font-mono text-2xl font-semibold text-slate-900 tabular-nums">
              {summary.open_count}
            </div>
            <div className="mt-2 text-xs text-slate-600 tabular-nums">
              {summary.pending_count} pending · {summary.in_progress_count} in progress
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-lg p-5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-500">
                Overdue &amp; Critical Alerts
              </span>
              {summary.overdue_count > 0 && (
                <button
                  type="button"
                  onClick={onFilterOverdue}
                  className="text-xs font-medium text-blue-700 hover:underline whitespace-nowrap"
                >
                  View overdue
                </button>
              )}
            </div>
            <div
              className={`mt-2 font-mono text-2xl font-semibold tabular-nums ${
                summary.overdue_count > 0 ? 'text-red-600' : 'text-emerald-700'
              }`}
            >
              {summary.overdue_count}
            </div>
            <div className="mt-2 text-xs text-slate-600 tabular-nums">
              {summary.critical_open_count} critical open · avg age {summary.avg_open_age_days.toFixed(1)}d
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-lg p-5">
            <div className="text-xs font-medium text-slate-500">
              Pending Estimated Cost
            </div>
            <div className="mt-2 font-mono text-2xl font-semibold text-slate-900 tabular-nums">
              {formatCurrency(summary.pending_estimated_cost)}
            </div>
            <div className="mt-2 text-xs text-slate-500 tabular-nums">
              Portfolio total {formatCurrency(summary.total_estimated_cost)}
            </div>
          </div>
        </div>
      </section>

      {/* Dominant Focal Section: Category Breakdown + Monthly Trend */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <section
          aria-label="Issues by Category"
          className="xl:col-span-2 bg-white border border-slate-200 rounded-lg p-5"
        >
          <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-slate-200">
            <div>
              <h2 className="font-display text-base font-semibold text-slate-900">
                Maintenance Volume by Category
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Click any category row to filter the Issue Registry · Reference date{' '}
                <span className="font-mono tabular-nums">{summary.reference_date}</span>
              </p>
            </div>
            <div className="flex items-center gap-4 text-xs text-slate-600">
              <span className="flex items-center gap-1.5">
                <span className="inline-block w-2.5 h-2.5 bg-amber-600 rounded-xs" />
                Unresolved
              </span>
              <span className="flex items-center gap-1.5">
                <span className="inline-block w-2.5 h-2.5 bg-blue-700 rounded-xs" />
                Resolved
              </span>
            </div>
          </div>

          <div className="mt-4 space-y-3">
            {categoryEntries.map(([category, stats]) => {
              const openPct = (stats.open / maxCategoryTotal) * 100;
              const resolvedPct = (stats.resolved / maxCategoryTotal) * 100;
              return (
                <button
                  key={category}
                  type="button"
                  onClick={() => onFilterCategory(category)}
                  className="w-full text-left group hover:bg-slate-50 p-2 -mx-2 rounded-md transition-colors"
                >
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="font-medium text-slate-800 group-hover:text-blue-700">
                      {category}
                    </span>
                    <span className="font-mono text-slate-600 tabular-nums">
                      {stats.open} open · {stats.resolved} resolved ·{' '}
                      {formatCurrency(stats.cost)}
                    </span>
                  </div>
                  <div className="w-full h-3 bg-slate-100 rounded-xs overflow-hidden flex">
                    {stats.open > 0 && (
                      <div
                        className="h-full bg-amber-600"
                        style={{ width: `${openPct}%` }}
                        title={`${stats.open} unresolved`}
                      />
                    )}
                    {stats.resolved > 0 && (
                      <div
                        className="h-full bg-blue-700"
                        style={{ width: `${resolvedPct}%` }}
                        title={`${stats.resolved} resolved`}
                      />
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </section>

        {/* Monthly Trend & Priority Snapshot */}
        <section
          aria-label="Monthly Activity and Priority Breakdown"
          className="bg-white border border-slate-200 rounded-lg p-5 flex flex-col justify-between"
        >
          <div>
            <h2 className="font-display text-base font-semibold text-slate-900 pb-4 border-b border-slate-200">
              Monthly Intake Trend
            </h2>
            <div className="mt-4 space-y-3">
              {summary.monthly_trend.map((m) => (
                <div
                  key={m.month}
                  className="flex items-center justify-between py-1.5 border-b border-slate-100 last:border-b-0 text-sm"
                >
                  <span className="font-mono text-xs font-medium text-slate-700 tabular-nums">
                    {m.month}
                  </span>
                  <span className="font-mono text-xs text-slate-600 tabular-nums">
                    {m.reported} logged · {m.resolved} resolved · {m.open} open
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-200">
            <h3 className="text-xs font-semibold text-slate-700 mb-3">
              Open Backlog by Priority
            </h3>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {(['Critical', 'High', 'Medium', 'Low'] as const).map((pri) => (
                <div
                  key={pri}
                  className="flex items-center justify-between px-3 py-2 bg-slate-50 border border-slate-200 rounded-md"
                >
                  <span
                    className={
                      pri === 'Critical'
                        ? 'font-medium text-red-700'
                        : pri === 'High'
                        ? 'font-medium text-amber-700'
                        : 'text-slate-700'
                    }
                  >
                    {pri}
                  </span>
                  <span className="font-mono font-semibold text-slate-900 tabular-nums">
                    {summary.by_priority[pri] ?? 0}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </section>
      </div>

      {/* Block Workload + Threshold Warning Indicators */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <section
          aria-label="Hostel Block Workload"
          className="bg-white border border-slate-200 rounded-lg p-5"
        >
          <div className="pb-4 border-b border-slate-200">
            <h2 className="font-display text-base font-semibold text-slate-900">
              Hostel Block Workload
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Pending volume and estimated repair exposure per residential block
            </p>
          </div>
          <div className="mt-3 overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-xs font-medium text-slate-500">
                  <th className="py-2.5 pr-3">Block</th>
                  <th className="py-2.5 px-3 text-right">Total</th>
                  <th className="py-2.5 px-3 text-right">Open</th>
                  <th className="py-2.5 px-3 text-right">Overdue</th>
                  <th className="py-2.5 pl-3 text-right">Pending Cost</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {blockEntries.map(([block, stats]) => (
                  <tr
                    key={block}
                    className="hover:bg-slate-50 transition-colors"
                  >
                    <td className="py-2.5 pr-3">
                      <button
                        type="button"
                        onClick={() => onFilterBlock(block)}
                        className="font-medium text-slate-900 hover:text-blue-700 hover:underline text-left"
                      >
                        {block}
                      </button>
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-600">
                      {stats.total}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums font-medium text-slate-900">
                      {stats.open}
                    </td>
                    <td
                      className={`py-2.5 px-3 text-right font-mono tabular-nums font-medium ${
                        stats.overdue > 0 ? 'text-red-600' : 'text-slate-500'
                      }`}
                    >
                      {stats.overdue}
                    </td>
                    <td className="py-2.5 pl-3 text-right font-mono tabular-nums text-slate-800">
                      {formatCurrency(stats.pending_cost)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section
          aria-label="Threshold Warning Indicators"
          className="bg-white border border-slate-200 rounded-lg p-5"
        >
          <div className="flex items-center justify-between pb-4 border-b border-slate-200">
            <div>
              <h2 className="font-display text-base font-semibold text-slate-900">
                Threshold Warning Indicators
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Overdue deadlines, critical SLA breaches, cost anomalies, and block load alerts
              </p>
            </div>
            <span className="font-mono text-xs font-semibold text-slate-700 tabular-nums">
              {summary.warnings.length} active
            </span>
          </div>

          {summary.warnings.length === 0 ? (
            <div className="py-10 text-center text-sm text-slate-600 flex flex-col items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-600" aria-hidden="true" />
              <span>All SLA deadlines, costs, and block workloads are within limits.</span>
            </div>
          ) : (
            <div className="mt-3 divide-y divide-slate-100 max-h-80 overflow-y-auto pr-1">
              {summary.warnings.map((w, idx) => {
                const isTicket = w.request_id.startsWith('HMT-');
                return (
                  <div key={`${w.code}-${w.request_id}-${idx}`} className="py-3 flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 text-xs">
                        {w.severity === 'Critical' ? (
                          <span className="inline-flex items-center gap-1 font-semibold text-red-700">
                            <AlertTriangle className="w-3.5 h-3.5" aria-hidden="true" />
                            Critical
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 font-semibold text-amber-700">
                            <Clock className="w-3.5 h-3.5" aria-hidden="true" />
                            Warning
                          </span>
                        )}
                        <span className="text-slate-400">·</span>
                        <span className="font-mono text-slate-600">{w.code}</span>
                      </div>
                      <div className="mt-1 text-sm font-medium text-slate-900">
                        {w.title}
                      </div>
                      <div className="mt-0.5 text-xs text-slate-600">{w.detail}</div>
                    </div>
                    {isTicket && (
                      <button
                        type="button"
                        onClick={() => onInspectTicket(w.request_id)}
                        aria-label={`Inspect ${w.request_id}`}
                        className="shrink-0 inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-blue-700 hover:bg-blue-50 rounded-md whitespace-nowrap"
                      >
                        <span>Inspect</span>
                        <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
