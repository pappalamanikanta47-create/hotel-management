import { useState } from 'react';
import {
  CATEGORIES,
  HOSTEL_BLOCKS,
  PRIORITIES,
  computeDefaultDueDate,
  validateRequestForm,
  type MaintenanceRequest,
  type RequestFormValues,
} from '../utils/trackerLogic';

interface RegisterViewProps {
  referenceDate: string;
  onSubmitRequest: (
    payload: Record<string, unknown>
  ) => Promise<{ ok: boolean; record?: MaintenanceRequest; errors?: Record<string, string> }>;
  onCreatedSuccess: () => void;
}

function createInitialForm(referenceDate: string): RequestFormValues {
  const today = referenceDate || new Date().toISOString().slice(0, 10);
  return {
    hostel_block: 'Block B',
    room_number: '',
    category: 'Plumbing',
    priority: 'Medium',
    description: '',
    reporter_name: '',
    reported_date: today,
    due_date: computeDefaultDueDate(today, 'Medium'),
    estimated_cost: '0.00',
    assigned_staff: 'Unassigned',
    notes: '',
  };
}

export function RegisterView({
  referenceDate,
  onSubmitRequest,
  onCreatedSuccess,
}: RegisterViewProps) {
  const [values, setValues] = useState<RequestFormValues>(() =>
    createInitialForm(referenceDate)
  );
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const handleFieldChange = (field: keyof RequestFormValues, nextVal: string) => {
    setValues((prev) => {
      const updated = { ...prev, [field]: nextVal };
      if (field === 'priority' || field === 'reported_date') {
        updated.due_date = computeDefaultDueDate(
          field === 'reported_date' ? nextVal : prev.reported_date,
          field === 'priority' ? nextVal : prev.priority
        );
      }
      return updated;
    });
    if (errors[field]) {
      setErrors((prev) => {
        const copy = { ...prev };
        delete copy[field];
        return copy;
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    const clientErrors = validateRequestForm(values);
    if (Object.keys(clientErrors).length > 0) {
      setErrors(clientErrors);
      return;
    }

    setSubmitting(true);
    const res = await onSubmitRequest({
      hostel_block: values.hostel_block,
      room_number: values.room_number,
      category: values.category,
      priority: values.priority,
      status: 'Pending',
      description: values.description,
      reporter_name: values.reporter_name,
      reported_date: values.reported_date,
      due_date: values.due_date,
      estimated_cost: Number(values.estimated_cost.replace(/[$,\s]/g, '')),
      assigned_staff: values.assigned_staff,
      notes: values.notes,
    });
    setSubmitting(false);

    if (!res.ok) {
      setErrors(res.errors ?? { form: 'Validation failed on server.' });
      return;
    }

    setValues(createInitialForm(referenceDate));
    setErrors({});
    setFeedback(
      `Registered ${res.record?.request_id ?? 'new request'} and saved to JSON & CSV storage.`
    );
    onCreatedSuccess();
  };

  return (
    <div className="max-w-3xl space-y-6">
      <section className="bg-white border border-slate-200 rounded-lg p-6">
        <div className="pb-4 border-b border-slate-200">
          <h2 className="font-display text-lg font-semibold text-slate-900">
            Register Hostel Maintenance Request
          </h2>
          <p className="mt-1 text-sm text-slate-500">
            All inputs are validated against campus domain constraints before persisting to local JSON and CSV storage.
          </p>
        </div>

        {feedback && (
          <div
            role="status"
            className="mt-4 p-3 bg-emerald-50 border border-emerald-200 rounded-md text-sm text-emerald-800"
          >
            {feedback}
          </div>
        )}

        {errors.form && (
          <div
            role="alert"
            className="mt-4 p-3 bg-red-50 border border-red-200 rounded-md text-sm text-red-700"
          >
            {errors.form}
          </div>
        )}

        <form onSubmit={handleSubmit} noValidate className="mt-5 space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label
                htmlFor="reg-block"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Hostel Block
              </label>
              <select
                id="reg-block"
                value={values.hostel_block}
                onChange={(e) => handleFieldChange('hostel_block', e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                {HOSTEL_BLOCKS.map((b) => (
                  <option key={b} value={b}>
                    {b}
                  </option>
                ))}
              </select>
              {errors.hostel_block && (
                <p className="mt-1 text-xs text-red-600">{errors.hostel_block}</p>
              )}
            </div>

            <div>
              <label
                htmlFor="reg-room"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Room Number
              </label>
              <input
                id="reg-room"
                type="text"
                value={values.room_number}
                onChange={(e) => handleFieldChange('room_number', e.target.value)}
                placeholder="e.g., B-304"
                className={`w-full px-3 py-2 text-sm font-mono bg-white border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600 ${
                  errors.room_number ? 'border-red-500' : 'border-slate-300'
                }`}
              />
              {errors.room_number ? (
                <p className="mt-1 text-xs text-red-600">{errors.room_number}</p>
              ) : (
                <p className="mt-1 text-xs text-slate-500">
                  Format: 2–4 digits with optional prefix (B-304, 205)
                </p>
              )}
            </div>

            <div>
              <label
                htmlFor="reg-category"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Issue Category
              </label>
              <select
                id="reg-category"
                value={values.category}
                onChange={(e) => handleFieldChange('category', e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
              {errors.category && (
                <p className="mt-1 text-xs text-red-600">{errors.category}</p>
              )}
            </div>

            <div>
              <label
                htmlFor="reg-priority"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Priority Level
              </label>
              <select
                id="reg-priority"
                value={values.priority}
                onChange={(e) => handleFieldChange('priority', e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                {PRIORITIES.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
              {errors.priority && (
                <p className="mt-1 text-xs text-red-600">{errors.priority}</p>
              )}
            </div>
          </div>

          <div>
            <label
              htmlFor="reg-description"
              className="block text-xs font-medium text-slate-700 mb-1"
            >
              Issue Description
            </label>
            <textarea
              id="reg-description"
              rows={3}
              value={values.description}
              onChange={(e) => handleFieldChange('description', e.target.value)}
              placeholder="Describe the maintenance defect clearly (8–280 characters)..."
              className={`w-full px-3 py-2 text-sm bg-white border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600 ${
                errors.description ? 'border-red-500' : 'border-slate-300'
              }`}
            />
            {errors.description && (
              <p className="mt-1 text-xs text-red-600">{errors.description}</p>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label
                htmlFor="reg-reporter"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Reporter Name
              </label>
              <input
                id="reg-reporter"
                type="text"
                value={values.reporter_name}
                onChange={(e) => handleFieldChange('reporter_name', e.target.value)}
                placeholder="e.g., Priya Menon"
                className={`w-full px-3 py-2 text-sm bg-white border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600 ${
                  errors.reporter_name ? 'border-red-500' : 'border-slate-300'
                }`}
              />
              {errors.reporter_name && (
                <p className="mt-1 text-xs text-red-600">{errors.reporter_name}</p>
              )}
            </div>

            <div>
              <label
                htmlFor="reg-cost"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Estimated Repair Cost (USD)
              </label>
              <input
                id="reg-cost"
                type="text"
                inputMode="decimal"
                value={values.estimated_cost}
                onChange={(e) => handleFieldChange('estimated_cost', e.target.value)}
                placeholder="0.00"
                className={`w-full px-3 py-2 text-sm font-mono tabular-nums bg-white border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600 ${
                  errors.estimated_cost ? 'border-red-500' : 'border-slate-300'
                }`}
              />
              {errors.estimated_cost && (
                <p className="mt-1 text-xs text-red-600">{errors.estimated_cost}</p>
              )}
            </div>

            <div>
              <label
                htmlFor="reg-reported-date"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Reported Date
              </label>
              <input
                id="reg-reported-date"
                type="date"
                value={values.reported_date}
                onChange={(e) => handleFieldChange('reported_date', e.target.value)}
                className={`w-full px-3 py-2 text-sm font-mono tabular-nums bg-white border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600 ${
                  errors.reported_date ? 'border-red-500' : 'border-slate-300'
                }`}
              />
              {errors.reported_date && (
                <p className="mt-1 text-xs text-red-600">{errors.reported_date}</p>
              )}
            </div>

            <div>
              <label
                htmlFor="reg-due-date"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Target Due Date (SLA Auto-Suggested)
              </label>
              <input
                id="reg-due-date"
                type="date"
                value={values.due_date}
                onChange={(e) => handleFieldChange('due_date', e.target.value)}
                className={`w-full px-3 py-2 text-sm font-mono tabular-nums bg-white border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600 ${
                  errors.due_date ? 'border-red-500' : 'border-slate-300'
                }`}
              />
              {errors.due_date && (
                <p className="mt-1 text-xs text-red-600">{errors.due_date}</p>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label
                htmlFor="reg-staff"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Assigned Technician
              </label>
              <input
                id="reg-staff"
                type="text"
                value={values.assigned_staff}
                onChange={(e) => handleFieldChange('assigned_staff', e.target.value)}
                placeholder="Unassigned"
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div>
              <label
                htmlFor="reg-notes"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Administrative Notes (Optional)
              </label>
              <input
                id="reg-notes"
                type="text"
                value={values.notes}
                onChange={(e) => handleFieldChange('notes', e.target.value)}
                placeholder="Access instructions or warranty note"
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={() => {
                setValues(createInitialForm(referenceDate));
                setErrors({});
                setFeedback(null);
              }}
              className="px-4 py-2 text-sm font-medium text-slate-700 border border-slate-300 rounded-md hover:bg-slate-50"
            >
              Reset Form
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-4 py-2 text-sm font-medium text-white bg-blue-700 rounded-md hover:bg-blue-800 disabled:opacity-50"
            >
              {submitting ? 'Validating & Saving...' : 'Submit Maintenance Request'}
            </button>
          </div>
        </form>
      </section>
    </div>
  );
}
