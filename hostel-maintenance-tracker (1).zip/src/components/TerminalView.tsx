import { useEffect, useState } from 'react';
import { Play } from 'lucide-react';
import { stripAnsi } from '../utils/trackerLogic';

const QUICK_COMMANDS = [
  { cmd: 'menu', label: 'Show Menu' },
  { cmd: '1', label: '1 · Executive Summary' },
  { cmd: '3', label: '3 · List Records' },
  { cmd: '5', label: '5 · Threshold Warnings' },
  { cmd: 'overdue', label: 'Overdue Only' },
  { cmd: 'export md', label: 'Export Markdown' },
];

export function TerminalView() {
  const [command, setCommand] = useState('1');
  const [output, setOutput] = useState<string>('');
  const [running, setRunning] = useState(false);

  const executeCommand = async (cmdToRun: string) => {
    setRunning(true);
    try {
      const resp = await fetch('/api/terminal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command: cmdToRun }),
      });
      const data = await resp.json();
      if (data.ok) {
        setOutput(stripAnsi(data.output ?? ''));
      } else {
        setOutput(`Error: ${data.error ?? 'Command execution failed.'}`);
      }
    } catch (err) {
      setOutput(`Error: ${(err as Error).message}`);
    } finally {
      setRunning(false);
    }
  };

  useEffect(() => {
    void executeCommand('menu');
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!command.trim()) return;
    void executeCommand(command.trim());
  };

  return (
    <section
      aria-label="Python Terminal Interface Console"
      className="bg-white border border-slate-200 rounded-lg p-5 space-y-4"
    >
      <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-slate-200">
        <div>
          <h2 className="font-display text-base font-semibold text-slate-900">
            Python CLI Terminal Console
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Executes commands directly against the Python <span className="font-mono">hostel_tracker</span> CLI engine. Run <span className="font-mono">python3 main.py</span> locally for interactive stdin prompts.
          </p>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        {QUICK_COMMANDS.map((item) => (
          <button
            key={item.cmd}
            type="button"
            onClick={() => {
              setCommand(item.cmd);
              void executeCommand(item.cmd);
            }}
            className="px-3 py-1.5 text-xs font-medium bg-slate-100 text-slate-800 border border-slate-200 rounded-md hover:bg-slate-200 whitespace-nowrap"
          >
            {item.label}
          </button>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-2">
        <label htmlFor="cli-command-input" className="sr-only">
          Terminal Command
        </label>
        <input
          id="cli-command-input"
          type="text"
          value={command}
          onChange={(e) => setCommand(e.target.value)}
          placeholder="Enter CLI command (e.g., 1, 3, search Plumbing, overdue, 5)..."
          className="min-w-0 flex-1 px-3 py-2 font-mono text-sm bg-white border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600"
        />
        <button
          type="submit"
          disabled={running}
          className="px-4 py-2 text-xs font-medium text-white bg-blue-700 rounded-md hover:bg-blue-800 disabled:opacity-50 inline-flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0"
        >
          <Play className="w-3.5 h-3.5" aria-hidden="true" />
          <span>{running ? 'Running...' : 'Run Command'}</span>
        </button>
      </form>

      <pre
        aria-label="Terminal Output"
        className="p-4 bg-slate-900 text-slate-100 font-mono text-xs rounded-md overflow-x-auto min-h-[360px] max-h-[520px] leading-relaxed"
      >
        {output || 'Waiting for Python CLI output...'}
      </pre>
    </section>
  );
}
