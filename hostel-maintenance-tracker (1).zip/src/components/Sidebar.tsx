import {
  AlertTriangle,
  ClipboardList,
  FileSpreadsheet,
  LayoutDashboard,
  PlusSquare,
  Terminal,
} from 'lucide-react';

export type NavTab = 'overview' | 'registry' | 'register' | 'reports' | 'terminal';

interface SidebarProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  openCount: number;
  warningCount: number;
}

const NAV_ITEMS: { id: NavTab; label: string; icon: typeof LayoutDashboard }[] = [
  { id: 'overview', label: 'Executive Summary', icon: LayoutDashboard },
  { id: 'registry', label: 'Issue Registry', icon: ClipboardList },
  { id: 'register', label: 'Register Request', icon: PlusSquare },
  { id: 'reports', label: 'Import & Exports', icon: FileSpreadsheet },
  { id: 'terminal', label: 'Terminal Console', icon: Terminal },
];

export function Sidebar({
  activeTab,
  onSelectTab,
  openCount,
  warningCount,
}: SidebarProps) {
  return (
    <aside
      aria-label="Primary Sidebar Navigation"
      className="w-full lg:w-64 shrink-0 border-b lg:border-b-0 lg:border-r border-slate-200 bg-white flex flex-col justify-between"
    >
      <div className="p-4 lg:p-5">
        <div className="pb-4 mb-4 border-b border-slate-200">
          <div className="font-display text-base font-bold tracking-tight text-slate-900">
            Hostel Maintenance Tracker
          </div>
          <p className="mt-1 text-xs text-slate-500">
            Campus &amp; Administration
          </p>
        </div>

        <nav className="flex lg:flex-col gap-1 overflow-x-auto lg:overflow-visible">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelectTab(item.id)}
                aria-current={isActive ? 'page' : undefined}
                className={`lg:w-full flex items-center justify-between gap-2 px-2.5 py-2.5 text-sm font-medium rounded-md transition-colors whitespace-nowrap shrink-0 text-left ${
                  isActive
                    ? 'bg-blue-50 text-blue-700'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <span className="flex items-center gap-2 min-w-0">
                  <Icon className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span className="truncate">{item.label}</span>
                </span>
                {item.id === 'registry' && (
                  <span className="font-mono text-xs tabular-nums text-slate-500 shrink-0">
                    {openCount}
                  </span>
                )}
                {item.id === 'overview' && warningCount > 0 && (
                  <span className="flex items-center gap-1 font-mono text-xs tabular-nums text-amber-700 shrink-0">
                    <AlertTriangle className="w-3.5 h-3.5" aria-hidden="true" />
                    {warningCount}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      <div className="hidden lg:block p-5 border-t border-slate-200 text-xs text-slate-500 space-y-1">
        <div className="font-medium text-slate-700">Local Persistence Active</div>
        <div className="font-mono text-[11px] text-slate-500">
          maintenance_requests.json · .csv
        </div>
      </div>
    </aside>
  );
}
