import { useState } from 'react';
import { RotateCcw, Search, X } from 'lucide-react';
import {
  CATEGORIES,
  HOSTEL_BLOCKS,
  PRIORITIES,
  STATUSES,
  formatCurrency,
  isRecordOverdue,
  type MaintenanceRequest,
} from '../utils/trackerLogic';

export interface RegistryFilters {
  keyword: string;
  category: string;
  block: string;
  status: string;
  priority: string;
  overdueOnly: boolean;
}

interface RegistryViewProps {
  records: MaintenanceRequest[];
  totalStored: number;
  referenceDate: string;
  filters: RegistryFilters;
  loading: boolean;
  onChangeFilters: (next: RegistryFilters) => void;
  onResetFilters: () => void;
  onUpdateStatus: (
    requestId: string,
    status: string,
    assignedStaff: string,
    notes: string
  ) => Promise<boolean>;
  onNavigateRegister: () => void;
  selectedRecord: MaintenanceRequest | null;
  onSelectRecord: (rec: MaintenanceRequest | null) => void;
}

export function RegistryView({
  records,
  totalStored,
  referenceDate,
  filters,
  loading,
  onChangeFilters,
  onResetFilters,
  onUpdateStatus,
  onNavigateRegister,
  selectedRecord,
  onSelectRecord,
}: RegistryViewProps) {
  const [editStatus, setEditStatus] = useState('');
  const [editStaff, setEditStaff] = useState('');
  const [editNotes, setEditNotes] = useState('');
  const [saving, setSaving] = useState(false);

  const openInspector = (rec: MaintenanceRequest) => {
    onSelectRecord(rec);
    setEditStatus(rec.status);
    setEditStaff(rec.assigned_staff);
    setEditNotes(rec.notes);
  };

  const handleSaveInspection = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRecord) return;
    setSaving(true);
    const ok = await onUpdateStatus(
      selectedRecord.request_id,
      editStatus || selectedRecord.status,
      editStaff,
      editNotes
    );
    setSaving(false);
    if (ok) {
      onSelectRecord(null);
    }
  };

  return (
    <div className="space-y-4">
      {/* Filter Toolbar */}
      <section
        aria-label="Search and Filter Records"
        className="bg-white border border-slate-200 rounded-lg p-4 space-y-3"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-6 gap-3">
          <div className="xl:col-span-2">
            <label
              htmlFor="registry-keyword"
              className="block text-xs font-medium text-slate-600 mb-1"
            >
              Keyword Search
            </label>
            <div className="relative">
              <Search
                className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2"
                aria-hidden="true"
              />
              <input
                id="registry-keyword"
                type="search"
                value={filters.keyword}
                onChange={(e) =>
                  onChangeFilters({ ...filters, keyword: e.target.value })
                }
                placeholder="ID, room, reporter, or description..."
                className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>
          </div>

          <div>
            <label
              htmlFor="filter-category"
              className="block text-xs font-medium text-slate-600 mb-1"
            >
              Category
            </label>
            <select
              id="filter-category"
              value={filters.category}
              onChange={(e) =>
                onChangeFilters({ ...filters, category: e.target.value })
              }
              className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600"
            >
              <option value="All">All Categories</option>
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label
              htmlFor="filter-block"
              className="block text-xs font-medium text-slate-600 mb-1"
            >
              Hostel Block
            </label>
            <select
              id="filter-block"
              value={filters.block}
              onChange={(e) =>
                onChangeFilters({ ...filters, block: e.target.value })
              }
              className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600"
            >
              <option value="All">All Blocks</option>
              {HOSTEL_BLOCKS.map((b) => (
                <option key={b} value={b}>
                  {b}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label
              htmlFor="filter-status"
              className="block text-xs font-medium text-slate-600 mb-1"
            >
              Status
            </label>
            <select
              id="filter-status"
              value={filters.status}
              onChange={(e) =>
                onChangeFilters({ ...filters, status: e.target.value })
              }
              className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600"
            >
              <option value="All">All Statuses</option>
              <option value="Open">Unresolved (Open)</option>
              {STATUSES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label
              htmlFor="filter-priority"
              className="block text-xs font-medium text-slate-600 mb-1"
            >
              Priority
            </label>
            <select
              id="filter-priority"
              value={filters.priority}
              onChange={(e) =>
                onChangeFilters({ ...filters, priority: e.target.value })
              }
              className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600"
            >
              <option value="All">All Priorities</option>
              {PRIORITIES.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100">
          <div className="flex items-center gap-4">
            <label className="inline-flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={filters.overdueOnly}
                onChange={(e) =>
                  onChangeFilters({ ...filters, overdueOnly: e.target.checked })
                }
                className="rounded border-slate-300 text-blue-700 focus:ring-blue-600"
              />
              <span>Overdue deadlines only</span>
            </label>
            <button
              type="button"
              onClick={onResetFilters}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-600 hover:text-slate-900"
            >
              <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Reset filters</span>
            </button>
          </div>
          <div className="text-xs text-slate-500 font-mono tabular-nums">
            Showing {records.length} of {totalStored} stored request(s)
          </div>
        </div>
      </section>

      {/* High-Density Data Grid */}
      <section
        aria-label="Maintenance Records Table"
        className="bg-white border border-slate-200 rounded-lg overflow-hidden"
      >
        {loading ? (
          <div className="p-6 space-y-3" aria-busy="true">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="h-10 bg-slate-100 rounded animate-pulse" />
            ))}
          </div>
        ) : records.length === 0 ? (
          <div className="p-10 text-center space-y-3">
            <p className="text-sm font-medium text-slate-900">
              No maintenance requests match the active filters.
            </p>
            <p className="text-xs text-slate-500">
              Adjust your search criteria or log a new hostel maintenance request.
            </p>
            <div className="flex items-center justify-center gap-3 pt-1">
              <button
                type="button"
                onClick={onResetFilters}
                className="px-3 py-1.5 text-xs font-medium text-slate-700 border border-slate-300 rounded-md hover:bg-slate-50"
              >
                Clear Filters
              </button>
              <button
                type="button"
                onClick={onNavigateRegister}
                className="px-3 py-1.5 text-xs font-medium text-white bg-blue-700 rounded-md hover:bg-blue-800"
              >
                Register Request
              </button>
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                  <th className="py-2.5 pl-4 pr-2 whitespace-nowrap">Request ID</th>
                  <th className="py-2.5 px-2.5 whitespace-nowrap">Location</th>
                  <th className="py-2.5 px-2.5 whitespace-nowrap">Category &amp; Summary</th>
                  <th className="py-2.5 px-2.5 whitespace-nowrap">Priority</th>
                  <th className="py-2.5 px-2.5 whitespace-nowrap">Status</th>
                  <th className="py-2.5 px-2.5 whitespace-nowrap">Due Date</th>
                  <th className="py-2.5 px-2.5 text-right whitespace-nowrap">Est. Cost</th>
                  <th className="py-2.5 pl-2.5 pr-4 text-right whitespace-nowrap">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {records.map((rec) => {
                  const overdue = isRecordOverdue(rec, referenceDate);
                  return (
                    <tr
                      key={rec.request_id}
                      className="hover:bg-slate-50 transition-colors"
                    >
                      <td className="py-2.5 pl-4 pr-2 font-mono text-xs font-medium text-slate-900 whitespace-nowrap tabular-nums">
                        {rec.request_id}
                      </td>
                      <td className="py-2.5 px-2.5 whitespace-nowrap">
                        <div className="text-xs font-medium text-slate-900">
                          {rec.hostel_block} · <span className="font-mono tabular-nums">{rec.room_number}</span>
                        </div>
                        <div className="text-xs text-slate-500">
                          {rec.reporter_name}
                        </div>
                      </td>
                      <td className="py-2.5 px-2.5 max-w-[260px]">
                        <div className="text-xs font-medium text-slate-700 truncate">
                          {rec.category} · <span className="text-slate-500 font-normal">{rec.assigned_staff}</span>
                        </div>
                        <div className="text-xs text-slate-900 truncate" title={rec.description}>
                          {rec.description}
                        </div>
                      </td>
                      <td className="py-2.5 px-2.5 whitespace-nowrap text-xs font-medium">
                        <span
                          className={
                            rec.priority === 'Critical'
                              ? 'text-red-700'
                              : rec.priority === 'High'
                              ? 'text-amber-700'
                              : 'text-slate-700'
                          }
                        >
                          {rec.priority}
                        </span>
                      </td>
                      <td className="py-2.5 px-2.5 whitespace-nowrap text-xs font-medium">
                        <span
                          className={
                            rec.status === 'Resolved'
                              ? 'text-emerald-700'
                              : overdue
                              ? 'text-red-700'
                              : 'text-amber-700'
                          }
                        >
                          {rec.status}
                          {overdue ? ' (Overdue)' : ''}
                        </span>
                      </td>
                      <td
                        className={`py-2.5 px-2.5 font-mono text-xs whitespace-nowrap tabular-nums ${
                          overdue ? 'text-red-700 font-semibold' : 'text-slate-600'
                        }`}
                      >
                        {rec.due_date}
                      </td>
                      <td className="py-2.5 px-2.5 text-right font-mono text-xs text-slate-900 whitespace-nowrap tabular-nums">
                        {formatCurrency(rec.estimated_cost)}
                      </td>
                      <td className="py-2.5 pl-2.5 pr-4 text-right whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => openInspector(rec)}
                          aria-label={`Update ${rec.request_id}`}
                          className="px-2.5 py-1 text-xs font-medium text-blue-700 hover:bg-blue-50 rounded-md whitespace-nowrap"
                        >
                          Update
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* Accessible Inspector / Status Update Modal */}
      {selectedRecord && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="modal-ticket-title"
          className="fixed inset-0 z-50 bg-slate-900/40 flex items-center justify-center p-4"
        >
          <div className="bg-white border border-slate-200 rounded-lg max-w-lg w-full p-6 shadow-lg">
            <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-200">
              <div>
                <div className="font-mono text-xs text-slate-500 tabular-nums">
                  {selectedRecord.request_id} · {selectedRecord.hostel_block} · {selectedRecord.room_number}
                </div>
                <h2
                  id="modal-ticket-title"
                  className="font-display text-base font-semibold text-slate-900 mt-1"
                >
                  Update Maintenance Status
                </h2>
              </div>
              <button
                type="button"
                onClick={() => onSelectRecord(null)}
                aria-label="Close modal"
                className="p-1.5 text-slate-500 hover:text-slate-900 rounded-md hover:bg-slate-100"
              >
                <X className="w-4 h-4" aria-hidden="true" />
              </button>
            </div>

            <div className="py-4 space-y-2 text-xs text-slate-600 border-b border-slate-200">
              <div className="text-sm text-slate-900 font-medium">
                {selectedRecord.description}
              </div>
              <div className="tabular-nums">
                {selectedRecord.category} · Priority: {selectedRecord.priority} · Reported {selectedRecord.reported_date} · Due {selectedRecord.due_date}
              </div>
              <div className="tabular-nums">
                Reporter: {selectedRecord.reporter_name} · Est. Cost: {formatCurrency(selectedRecord.estimated_cost)}
              </div>
            </div>

            <form onSubmit={handleSaveInspection} className="pt-4 space-y-4">
              <div>
                <label
                  htmlFor="modal-status"
                  className="block text-xs font-medium text-slate-700 mb-1"
                >
                  Workflow Status
                </label>
                <select
                  id="modal-status"
                  value={editStatus || selectedRecord.status}
                  onChange={(e) => setEditStatus(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600"
                >
                  {STATUSES.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label
                  htmlFor="modal-staff"
                  className="block text-xs font-medium text-slate-700 mb-1"
                >
                  Assigned Technician / Crew
                </label>
                <input
                  id="modal-staff"
                  type="text"
                  value={editStaff}
                  onChange={(e) => setEditStaff(e.target.value)}
                  placeholder="e.g., R. Nair"
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div>
                <label
                  htmlFor="modal-notes"
                  className="block text-xs font-medium text-slate-700 mb-1"
                >
                  Resolution / Inspection Notes
                </label>
                <textarea
                  id="modal-notes"
                  rows={3}
                  value={editNotes}
                  onChange={(e) => setEditNotes(e.target.value)}
                  placeholder="Record inspection findings or parts replaced..."
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => onSelectRecord(null)}
                  className="px-4 py-2 text-xs font-medium text-slate-700 border border-slate-300 rounded-md hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-4 py-2 text-xs font-medium text-white bg-blue-700 rounded-md hover:bg-blue-800 disabled:opacity-50"
                >
                  {saving ? 'Saving...' : 'Save Status'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
