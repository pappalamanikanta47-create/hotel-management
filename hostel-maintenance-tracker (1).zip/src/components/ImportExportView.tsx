import { useState } from 'react';
import { Download, FileText, Upload } from 'lucide-react';
import type { BulkImportResult } from '../utils/trackerLogic';

interface ImportExportViewProps {
  onImportComplete: () => Promise<void>;
}

export function ImportExportView({ onImportComplete }: ImportExportViewProps) {
  const [exportFormat, setExportFormat] = useState<'md' | 'txt' | 'csv'>('md');
  const [exportPreview, setExportPreview] = useState<string>('');
  const [exportFilename, setExportFilename] = useState<string>('');
  const [exportLoading, setExportLoading] = useState(false);

  const [csvText, setCsvText] = useState('');
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState<BulkImportResult | null>(null);
  const [importError, setImportError] = useState<string | null>(null);

  const handleGenerateExport = async (fmt: 'md' | 'txt' | 'csv') => {
    setExportFormat(fmt);
    setExportLoading(true);
    try {
      const resp = await fetch(`/api/export?format=${fmt}`);
      const data = await resp.json();
      if (data.ok) {
        setExportPreview(data.content);
        setExportFilename(data.filename);
      }
    } finally {
      setExportLoading(false);
    }
  };

  const handleDownloadExport = () => {
    if (!exportPreview) return;
    const blob = new Blob([exportPreview], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = exportFilename || `maintenance_report.${exportFormat}`;
    anchor.click();
    URL.revokeObjectURL(url);
  };

  const handleLoadSampleCsv = async () => {
    setImportError(null);
    const resp = await fetch('/api/sample-import-csv');
    const data = await resp.json();
    if (data.ok) {
      setCsvText(data.content);
    } else {
      setImportError(data.error ?? 'Could not load sample legacy CSV.');
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setCsvText(reader.result);
      }
    };
    reader.readAsText(file);
  };

  const handleRunBulkImport = async () => {
    setImportError(null);
    setImporting(true);
    try {
      const resp = await fetch('/api/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ csv_text: csvText }),
      });
      const data = await resp.json();
      if (data.ok && data.result) {
        setImportResult(data.result);
        if (data.result.imported_count > 0) {
          await onImportComplete();
        }
      } else {
        setImportError(data.error ?? 'Bulk import failed.');
      }
    } catch (err) {
      setImportError((err as Error).message);
    } finally {
      setImporting(false);
    }
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
      {/* Multi-Format Summary Export */}
      <section
        aria-label="Multi-Format Summary Export"
        className="bg-white border border-slate-200 rounded-lg p-5 flex flex-col justify-between space-y-4"
      >
        <div>
          <div className="pb-4 border-b border-slate-200">
            <h2 className="font-display text-base font-semibold text-slate-900">
              Multi-Format Summary Export
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Generate structured Markdown summaries, plain-text audit logs, or standardized CSV reports directly from the Python engine.
            </p>
          </div>

          <div className="mt-4 flex flex-wrap items-center gap-2">
            {(
              [
                { id: 'md', label: 'Markdown (.md)' },
                { id: 'txt', label: 'Audit Log (.txt)' },
                { id: 'csv', label: 'CSV Report (.csv)' },
              ] as const
            ).map((btn) => (
              <button
                key={btn.id}
                type="button"
                onClick={() => handleGenerateExport(btn.id)}
                className={`px-3 py-2 text-xs font-medium rounded-md border transition-colors whitespace-nowrap ${
                  exportFormat === btn.id && exportPreview
                    ? 'bg-blue-700 text-white border-blue-700'
                    : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                }`}
              >
                <span className="inline-flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5" aria-hidden="true" />
                  {btn.label}
                </span>
              </button>
            ))}
          </div>

          {exportPreview && (
            <div className="mt-3 flex items-center justify-between gap-2 px-3 py-2 bg-slate-50 border border-slate-200 rounded-md">
              <span className="font-mono text-xs text-slate-700 truncate">
                {exportFilename}
              </span>
              <button
                type="button"
                onClick={handleDownloadExport}
                className="px-3 py-1.5 text-xs font-medium text-blue-700 bg-white border border-blue-200 rounded-md hover:bg-blue-50 whitespace-nowrap shrink-0"
              >
                <span className="inline-flex items-center gap-1.5">
                  <Download className="w-3.5 h-3.5" aria-hidden="true" />
                  Download
                </span>
              </button>
            </div>
          )}

          <div className="mt-3">
            {exportLoading ? (
              <div className="h-80 bg-slate-100 rounded-md animate-pulse" />
            ) : exportPreview ? (
              <pre
                aria-label="Export Preview"
                className="h-80 overflow-auto p-4 bg-slate-900 text-slate-100 font-mono text-xs rounded-md leading-relaxed"
              >
                {exportPreview}
              </pre>
            ) : (
              <div className="h-80 border border-dashed border-slate-300 rounded-md flex items-center justify-center p-6 text-center text-xs text-slate-500">
                Select Markdown, Audit Log, or CSV Report above to preview and download the generated summary.
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Bulk Legacy CSV Import */}
      <section
        aria-label="Bulk Dataset Import"
        className="bg-white border border-slate-200 rounded-lg p-5 space-y-4"
      >
        <div className="pb-4 border-b border-slate-200">
          <h2 className="font-display text-base font-semibold text-slate-900">
            Bulk Legacy CSV Import
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Ingest legacy CSV spreadsheets with automatic field validation and a detailed row-by-row error log.
          </p>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleLoadSampleCsv}
              className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 border border-slate-300 rounded-md hover:bg-slate-200 whitespace-nowrap"
            >
              Load Sample Legacy CSV
            </button>
            <label className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-md hover:bg-slate-50 cursor-pointer inline-flex items-center gap-1.5 whitespace-nowrap">
              <Upload className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Upload CSV File</span>
              <input
                type="file"
                accept=".csv,text/csv"
                onChange={handleFileUpload}
                className="sr-only"
              />
            </label>
          </div>

          <button
            type="button"
            onClick={handleRunBulkImport}
            disabled={importing}
            className="px-4 py-1.5 text-xs font-medium text-white bg-blue-700 rounded-md hover:bg-blue-800 disabled:opacity-50 whitespace-nowrap"
          >
            {importing ? 'Validating...' : 'Validate & Import CSV'}
          </button>
        </div>

        <div>
          <label
            htmlFor="bulk-csv-textarea"
            className="block text-xs font-medium text-slate-700 mb-1"
          >
            CSV Payload
          </label>
          <textarea
            id="bulk-csv-textarea"
            rows={8}
            value={csvText}
            onChange={(e) => setCsvText(e.target.value)}
            placeholder="Paste CSV rows with header: hostel_block,room_number,category,priority,status,description,reporter_name,reported_date,due_date,estimated_cost"
            className="w-full p-3 font-mono text-xs bg-white border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600"
          />
        </div>

        {importError && (
          <div role="alert" className="p-3 bg-red-50 border border-red-200 rounded-md text-xs text-red-700">
            {importError}
          </div>
        )}

        {importResult && (
          <div className="border border-slate-200 rounded-md p-4 space-y-3 bg-slate-50">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-medium">
              <span className="text-slate-900 font-mono tabular-nums">
                Processed {importResult.total_rows} row(s)
              </span>
              <span className="font-mono tabular-nums">
                <span className="text-emerald-700">{importResult.imported_count} imported</span>
                {' · '}
                <span className="text-amber-700">{importResult.skipped_count} skipped</span>
              </span>
            </div>

            {importResult.imported_ids.length > 0 && (
              <div className="text-xs text-slate-700">
                Imported IDs:{' '}
                <span className="font-mono">{importResult.imported_ids.join(', ')}</span>
              </div>
            )}

            {importResult.error_log.length > 0 && (
              <div className="space-y-2">
                <div className="text-xs font-semibold text-red-700">
                  Row-by-Row Validation Error Log
                </div>
                <div className="max-h-44 overflow-y-auto space-y-1.5">
                  {importResult.error_log.map((errItem) => (
                    <div
                      key={errItem.row_number}
                      className="p-2.5 bg-white border border-red-200 rounded text-xs"
                    >
                      <span className="font-mono font-semibold text-red-700">
                        Row {errItem.row_number}:
                      </span>{' '}
                      <span className="text-slate-700">
                        {errItem.errors.join(' | ')}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </section>
    </div>
  );
}
