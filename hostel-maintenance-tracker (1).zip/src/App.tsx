/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useCallback, useEffect, useState } from 'react';
import { Plus } from 'lucide-react';
import { ImportExportView } from './components/ImportExportView';
import { OverviewView } from './components/OverviewView';
import { RegisterView } from './components/RegisterView';
import { RegistryView, type RegistryFilters } from './components/RegistryView';
import { Sidebar, type NavTab } from './components/Sidebar';
import { TerminalView } from './components/TerminalView';
import type { ExecutiveSummary, MaintenanceRequest } from './utils/trackerLogic';

const INITIAL_FILTERS: RegistryFilters = {
  keyword: '',
  category: 'All',
  block: 'All',
  status: 'All',
  priority: 'All',
  overdueOnly: false,
};

const TAB_TITLES: Record<NavTab, string> = {
  overview: 'Executive Summary',
  registry: 'Issue Registry',
  register: 'Register Request',
  reports: 'Import & Exports',
  terminal: 'Terminal Console',
};

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('overview');
  const [records, setRecords] = useState<MaintenanceRequest[]>([]);
  const [totalStored, setTotalStored] = useState(0);
  const [summary, setSummary] = useState<ExecutiveSummary | null>(null);
  const [notices, setNotices] = useState<string[]>([]);
  const [filters, setFilters] = useState<RegistryFilters>(INITIAL_FILTERS);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [selectedRecord, setSelectedRecord] = useState<MaintenanceRequest | null>(null);

  const fetchState = useCallback(async (activeFilters: RegistryFilters) => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const params = new URLSearchParams({
        keyword: activeFilters.keyword,
        category: activeFilters.category,
        block: activeFilters.block,
        status: activeFilters.status,
        priority: activeFilters.priority,
        overdue_only: String(activeFilters.overdueOnly),
      });
      const resp = await fetch(`/api/state?${params.toString()}`);
      const data = await resp.json();
      if (!data.ok) {
        throw new Error(data.error ?? 'Failed to load maintenance state.');
      }
      setRecords(data.records ?? []);
      setTotalStored(data.total_stored ?? 0);
      setSummary(data.summary ?? null);
      setNotices(data.notices ?? []);
    } catch (err) {
      setErrorMsg((err as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchState(filters);
  }, [fetchState, filters]);

  const handleSubmitRequest = async (payload: Record<string, unknown>) => {
    const resp = await fetch('/api/requests', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await resp.json();
    if (data.ok) {
      await fetchState(filters);
    }
    return data;
  };

  const handleUpdateStatus = async (
    requestId: string,
    status: string,
    assignedStaff: string,
    notes: string
  ): Promise<boolean> => {
    try {
      const resp = await fetch(`/api/requests/${encodeURIComponent(requestId)}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status,
          assigned_staff: assignedStaff,
          notes,
        }),
      });
      const data = await resp.json();
      if (!data.ok) {
        setErrorMsg(data.error ?? 'Failed to update status.');
        return false;
      }
      await fetchState(filters);
      return true;
    } catch (err) {
      setErrorMsg((err as Error).message);
      return false;
    }
  };

  const handleInspectTicket = (requestId: string) => {
    const match = records.find((r) => r.request_id === requestId) ?? null;
    setFilters({ ...INITIAL_FILTERS, keyword: requestId });
    setActiveTab('registry');
    if (match) {
      setSelectedRecord(match);
    }
  };

  const handleFilterOverdue = () => {
    setFilters({ ...INITIAL_FILTERS, overdueOnly: true });
    setActiveTab('registry');
  };

  const handleFilterBlock = (block: string) => {
    setFilters({ ...INITIAL_FILTERS, block, status: 'Open' });
    setActiveTab('registry');
  };

  const handleFilterCategory = (category: string) => {
    setFilters({ ...INITIAL_FILTERS, category });
    setActiveTab('registry');
  };

  const referenceDate =
    summary?.reference_date ?? new Date().toISOString().slice(0, 10);

  return (
    <div className="min-h-screen flex flex-col lg:flex-row bg-slate-50 text-slate-900">
      <Sidebar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        openCount={summary?.open_count ?? 0}
        warningCount={summary?.warnings.length ?? 0}
      />

      <div className="flex-1 min-w-0 flex flex-col">
        {/* Top Header Bar: Breadcrumb on Left + 1 Primary CTA on Right */}
        <header className="bg-white border-b border-slate-200 px-6 py-3.5 flex items-center justify-between gap-8">
          <div className="min-w-0 flex items-center gap-2 text-sm text-slate-500 truncate">
            <span className="hidden sm:inline">Campus &amp; Administration</span>
            <span className="hidden sm:inline" aria-hidden="true">/</span>
            <span className="font-medium text-slate-700 truncate">
              Hostel Maintenance Tracker
            </span>
            <span aria-hidden="true">/</span>
            <h1 className="font-display font-semibold text-slate-900 truncate">
              {TAB_TITLES[activeTab]}
            </h1>
          </div>

          <div className="shrink-0">
            <button
              type="button"
              onClick={() => setActiveTab('register')}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-blue-700 rounded-md hover:bg-blue-800 transition-colors whitespace-nowrap shrink-0"
            >
              <Plus className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Register Request</span>
            </button>
          </div>
        </header>

        <main className="flex-1 p-6 max-w-7xl w-full mx-auto space-y-5">
          {notices.length > 0 && (
            <div
              role="status"
              className="p-3 bg-amber-50 border border-amber-200 rounded-md text-xs text-amber-900"
            >
              {notices.join(' ')}
            </div>
          )}

          {errorMsg && (
            <div
              role="alert"
              className="p-3 bg-red-50 border border-red-200 rounded-md text-xs text-red-700 flex items-center justify-between gap-4"
            >
              <span>{errorMsg}</span>
              <button
                type="button"
                onClick={() => setErrorMsg(null)}
                className="font-medium underline shrink-0"
              >
                Dismiss
              </button>
            </div>
          )}

          {activeTab === 'overview' && (
            <OverviewView
              summary={summary}
              loading={loading}
              onFilterOverdue={handleFilterOverdue}
              onFilterBlock={handleFilterBlock}
              onFilterCategory={handleFilterCategory}
              onInspectTicket={handleInspectTicket}
            />
          )}

          {activeTab === 'registry' && (
            <RegistryView
              records={records}
              totalStored={totalStored}
              referenceDate={referenceDate}
              filters={filters}
              loading={loading}
              onChangeFilters={setFilters}
              onResetFilters={() => setFilters(INITIAL_FILTERS)}
              onUpdateStatus={handleUpdateStatus}
              onNavigateRegister={() => setActiveTab('register')}
              selectedRecord={selectedRecord}
              onSelectRecord={setSelectedRecord}
            />
          )}

          {activeTab === 'register' && (
            <RegisterView
              referenceDate={referenceDate}
              onSubmitRequest={handleSubmitRequest}
              onCreatedSuccess={() => setActiveTab('registry')}
            />
          )}

          {activeTab === 'reports' && (
            <ImportExportView onImportComplete={() => fetchState(filters)} />
          )}

          {activeTab === 'terminal' && <TerminalView />}
        </main>
      </div>
    </div>
  );
}
