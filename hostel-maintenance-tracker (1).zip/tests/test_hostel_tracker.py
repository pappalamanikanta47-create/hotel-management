"""Comprehensive unit tests for Hostel Maintenance Tracker Python modules."""

from __future__ import annotations

import tempfile
import unittest
from datetime import date
from pathlib import Path

from hostel_tracker.engine import (
    query_requests,
    register_request,
    summarize_pending_issues,
    update_request_status,
)
from hostel_tracker.exporter import (
    export_report_to_file,
    render_audit_log,
    render_csv_report,
    render_markdown_report,
)
from hostel_tracker.importer import import_csv_content
from hostel_tracker.models import MaintenanceRequest
from hostel_tracker.storage import load_records, save_records
from hostel_tracker.validation import (
    validate_iso_date,
    validate_positive_float,
    validate_request_payload,
    validate_room_number,
)


class HostelTrackerTests(unittest.TestCase):
    def setUp(self) -> None:
        self.sample_payload = {
            "hostel_block": "Block B",
            "room_number": "b-204",
            "category": "Plumbing",
            "priority": "High",
            "status": "Pending",
            "description": "Leaking overhead shower pipe joint",
            "reporter_name": "Aarav Sharma",
            "reported_date": "2026-11-10",
            "due_date": "2026-11-13",
            "estimated_cost": "185.50",
            "assigned_staff": "R. Nair",
        }

    def test_defensive_validation_rejects_invalid_inputs(self) -> None:
        ok_room, _, _ = validate_room_number("INVALID!!")
        self.assertFalse(ok_room)

        ok_cost, _, _ = validate_positive_float("-50")
        self.assertFalse(ok_cost)

        ok_date, _, _ = validate_iso_date("2026-02-30")
        self.assertFalse(ok_date)

        bad_payload = dict(self.sample_payload)
        bad_payload["due_date"] = "2026-11-01"  # earlier than reported_date
        bad_payload["description"] = "short"
        ok, _, errors = validate_request_payload(bad_payload)
        self.assertFalse(ok)
        self.assertIn("due_date", errors)
        self.assertIn("description", errors)

    def test_register_query_update_and_summarize(self) -> None:
        records: list[MaintenanceRequest] = []
        ok, created, errors = register_request(records, self.sample_payload)
        self.assertTrue(ok, msg=f"Unexpected errors: {errors}")
        assert created is not None
        self.assertEqual(created.request_id, "HMT-2026-0001")
        self.assertEqual(created.room_number, "B-204")

        # Overdue relative to 2026-11-20
        summary = summarize_pending_issues(records, reference_date=date(2026, 11, 20))
        self.assertEqual(summary.total_requests, 1)
        self.assertEqual(summary.pending_count, 1)
        self.assertEqual(summary.overdue_count, 1)
        self.assertEqual(summary.pending_estimated_cost, 185.50)
        self.assertTrue(any(w.code == "OVERDUE_DEADLINE" for w in summary.warnings))

        # Query by keyword and category
        matches = query_requests(records, keyword="shower", category="Plumbing")
        self.assertEqual(len(matches), 1)

        # Update to Resolved
        ok_upd, updated, _ = update_request_status(
            records, "HMT-2026-0001", "Resolved", resolved_date="2026-11-12"
        )
        self.assertTrue(ok_upd)
        assert updated is not None
        self.assertEqual(updated.status, "Resolved")
        summary_after = summarize_pending_issues(records, reference_date=date(2026, 11, 20))
        self.assertEqual(summary_after.overdue_count, 0)
        self.assertEqual(summary_after.resolution_rate_pct, 100.0)

    def test_storage_persistence_and_corruption_recovery(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_dir = Path(tmp)
            json_path = tmp_dir / "requests.json"
            csv_path = tmp_dir / "requests.csv"

            records: list[MaintenanceRequest] = []
            register_request(records, self.sample_payload)
            save_records(records, json_path=json_path, csv_path=csv_path)

            loaded, notices = load_records(json_path=json_path, csv_path=csv_path)
            self.assertEqual(len(loaded), 1)
            self.assertEqual(notices, [])

            # Corrupt JSON -> should fall back to CSV and rebuild JSON
            json_path.write_text("{broken json!!!", encoding="utf-8")
            recovered, rec_notices = load_records(json_path=json_path, csv_path=csv_path)
            self.assertEqual(len(recovered), 1)
            self.assertTrue(any("Recovered" in n for n in rec_notices))

    def test_bulk_csv_import_and_exports(self) -> None:
        csv_text = (
            "hostel_block,room_number,category,priority,status,description,reporter_name,reported_date,due_date,estimated_cost\n"
            "Block A,A-202,Electrical,Medium,Pending,Ceiling light ballast flickering loudly,Priya Nair,2026-11-18,2026-11-25,85.00\n"
            "Bad Block,99!,Electrical,Medium,Pending,Short,Priya Nair,2026-11-18,2026-11-10,-20\n"
        )
        records: list[MaintenanceRequest] = []
        result = import_csv_content(csv_text, records)
        self.assertEqual(result.total_rows, 2)
        self.assertEqual(result.imported_count, 1)
        self.assertEqual(result.skipped_count, 1)
        self.assertEqual(result.error_log[0].row_number, 3)

        md = render_markdown_report(records)
        txt = render_audit_log(records)
        csv_out = render_csv_report(records)
        self.assertIn("Hostel Maintenance Tracker", md)
        self.assertIn("ADMINISTRATIVE AUDIT LOG", txt)
        self.assertIn("HMT-2026-0001", csv_out)

        with tempfile.TemporaryDirectory() as tmp:
            out_path = export_report_to_file("md", records, exports_dir=Path(tmp))
            self.assertTrue(out_path.exists())


if __name__ == "__main__":
    unittest.main()
