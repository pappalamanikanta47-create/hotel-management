"""JSON-over-stdio bridge so the Express server executes real Python engine logic."""

from __future__ import annotations

import io
import json
import sys
from typing import Any, Dict

from hostel_tracker.cli import (
    handle_executive_summary,
    handle_warnings,
    print_banner,
    print_menu,
    render_table,
)
from hostel_tracker.engine import (
    query_requests,
    register_request,
    summarize_pending_issues,
    update_request_status,
)
from hostel_tracker.exporter import (
    render_audit_log,
    render_csv_report,
    render_markdown_report,
)
from hostel_tracker.importer import import_csv_content
from hostel_tracker.storage import (
    DEFAULT_CSV_PATH,
    DEFAULT_JSON_PATH,
    load_records,
    save_records,
)


def _read_stdin_json() -> Dict[str, Any]:
    raw = sys.stdin.read().strip()
    if not raw:
        return {}
    return json.loads(raw)


def _run_terminal_command(cmd: str) -> Dict[str, Any]:
    """Execute a terminal menu command or CLI shortcut and return captured terminal output."""
    records, notices = load_records()
    buf = io.StringIO()

    def out(text: str = "") -> None:
        buf.write(text + "\n")

    cleaned = cmd.strip().lower()
    if cleaned in ("menu", "help", "?"):
        print_banner(print_fn=out)
        print_menu(print_fn=out)
    elif cleaned in ("1", "summary"):
        handle_executive_summary(records, print_fn=out)
    elif cleaned in ("3", "list", "all"):
        render_table(records, page_size=12, print_fn=out, paginate=False)
    elif cleaned.startswith("search "):
        kw = cmd.strip()[7:].strip()
        matches = query_requests(records, keyword=kw)
        out(f"Query: '{kw}' -> {len(matches)} match(es)")
        render_table(matches, page_size=12, print_fn=out, paginate=False)
    elif cleaned in ("5", "warnings", "alerts"):
        handle_warnings(records, print_fn=out)
    elif cleaned in ("overdue",):
        matches = query_requests(records, overdue_only=True)
        out(f"Overdue Open Requests -> {len(matches)} match(es)")
        render_table(matches, page_size=15, print_fn=out, paginate=False)
    elif cleaned in ("export md", "6"):
        out(render_markdown_report(records))
    elif cleaned == "export txt":
        out(render_audit_log(records))
    else:
        out(f"Unknown terminal command '{cmd}'.")
        out("Available commands: menu, 1 (summary), 3 (list), search <keyword>, overdue, 5 (warnings), export md, export txt")

    return {
        "ok": True,
        "output": buf.getvalue(),
        "notices": notices,
        "record_count": len(records),
    }


def main() -> int:
    if len(sys.argv) < 2:
        print(json.dumps({"ok": False, "error": "Missing bridge action"}))
        return 1

    action = sys.argv[1]
    payload = _read_stdin_json()

    if action == "state":
        records, notices = load_records()
        filtered = query_requests(
            records,
            keyword=payload.get("keyword", ""),
            category=payload.get("category", "All"),
            block=payload.get("block", "All"),
            status=payload.get("status", "All"),
            priority=payload.get("priority", "All"),
            overdue_only=bool(payload.get("overdue_only", False)),
        )
        summary = summarize_pending_issues(records)
        print(
            json.dumps(
                {
                    "ok": True,
                    "records": [r.to_dict() for r in filtered],
                    "total_stored": len(records),
                    "summary": summary.to_dict(),
                    "notices": notices,
                    "storage_paths": {
                        "json": str(DEFAULT_JSON_PATH.name),
                        "csv": str(DEFAULT_CSV_PATH.name),
                    },
                }
            )
        )
        return 0

    if action == "register":
        records, _ = load_records()
        ok, created, errors = register_request(records, payload)
        if ok and created:
            save_records(records)
            summary = summarize_pending_issues(records)
            print(json.dumps({"ok": True, "record": created.to_dict(), "summary": summary.to_dict()}))
            return 0
        print(json.dumps({"ok": False, "errors": errors}))
        return 0

    if action == "update_status":
        records, _ = load_records()
        ok, updated, err = update_request_status(
            records,
            request_id=str(payload.get("request_id", "")),
            new_status=str(payload.get("status", "")),
            assigned_staff=payload.get("assigned_staff"),
            notes=payload.get("notes"),
        )
        if ok and updated:
            save_records(records)
            summary = summarize_pending_issues(records)
            print(json.dumps({"ok": True, "record": updated.to_dict(), "summary": summary.to_dict()}))
            return 0
        print(json.dumps({"ok": False, "error": err}))
        return 0

    if action == "import_csv":
        records, _ = load_records()
        csv_text = str(payload.get("csv_text", ""))
        result = import_csv_content(csv_text, records)
        if result.imported_count > 0:
            save_records(records)
        summary = summarize_pending_issues(records)
        print(
            json.dumps(
                {
                    "ok": True,
                    "result": result.to_dict(),
                    "summary": summary.to_dict(),
                }
            )
        )
        return 0

    if action == "export":
        records, _ = load_records()
        fmt = str(payload.get("format", "md")).lower()
        if fmt == "md":
            content = render_markdown_report(records)
            filename = "hostel_maintenance_summary.md"
            mime = "text/markdown"
        elif fmt == "txt":
            content = render_audit_log(records)
            filename = "hostel_maintenance_audit.txt"
            mime = "text/plain"
        elif fmt == "csv":
            content = render_csv_report(records)
            filename = "hostel_maintenance_report.csv"
            mime = "text/csv"
        else:
            print(json.dumps({"ok": False, "error": f"Unsupported format: {fmt}"}))
            return 0
        print(json.dumps({"ok": True, "format": fmt, "filename": filename, "mime": mime, "content": content}))
        return 0

    if action == "terminal":
        cmd = str(payload.get("command", "menu"))
        print(json.dumps(_run_terminal_command(cmd)))
        return 0

    print(json.dumps({"ok": False, "error": f"Unknown bridge action '{action}'"}))
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
