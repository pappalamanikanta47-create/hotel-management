"""Domain data structures and constants for Hostel Maintenance Tracker."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional

HOSTEL_BLOCKS: tuple[str, ...] = (
    "Block A",
    "Block B",
    "Block C",
    "Block D",
    "North Wing",
    "South Wing",
)

CATEGORIES: tuple[str, ...] = (
    "Plumbing",
    "Electrical",
    "Carpentry",
    "HVAC",
    "Sanitation",
    "Internet & Network",
    "Structural",
    "General",
)

PRIORITIES: tuple[str, ...] = (
    "Low",
    "Medium",
    "High",
    "Critical",
)

STATUSES: tuple[str, ...] = (
    "Pending",
    "In Progress",
    "Resolved",
)

SLA_DAYS_BY_PRIORITY: dict[str, int] = {
    "Critical": 1,
    "High": 3,
    "Medium": 7,
    "Low": 14,
}

MAX_ESTIMATED_COST: float = 50000.0
COST_ANOMALY_THRESHOLD: float = 1500.0
BLOCK_PENDING_THRESHOLD: int = 5


@dataclass
class MaintenanceRequest:
    """Represents a single campus hostel maintenance work order."""

    request_id: str
    hostel_block: str
    room_number: str
    category: str
    priority: str
    status: str
    description: str
    reporter_name: str
    reported_date: str
    due_date: str
    estimated_cost: float
    resolved_date: Optional[str] = None
    assigned_staff: str = "Unassigned"
    notes: str = ""

    def to_dict(self) -> Dict[str, Any]:
        """Serialize request into a JSON/CSV-friendly dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, raw: Dict[str, Any]) -> "MaintenanceRequest":
        """Construct a MaintenanceRequest from a dictionary with safe defaults."""
        resolved = raw.get("resolved_date")
        if resolved in ("", "None", None):
            resolved = None
        return cls(
            request_id=str(raw.get("request_id", "")).strip(),
            hostel_block=str(raw.get("hostel_block", "")).strip(),
            room_number=str(raw.get("room_number", "")).strip().upper(),
            category=str(raw.get("category", "")).strip(),
            priority=str(raw.get("priority", "Medium")).strip(),
            status=str(raw.get("status", "Pending")).strip(),
            description=str(raw.get("description", "")).strip(),
            reporter_name=str(raw.get("reporter_name", "")).strip(),
            reported_date=str(raw.get("reported_date", "")).strip(),
            due_date=str(raw.get("due_date", "")).strip(),
            estimated_cost=round(float(raw.get("estimated_cost", 0.0) or 0.0), 2),
            resolved_date=str(resolved).strip() if resolved else None,
            assigned_staff=str(raw.get("assigned_staff", "Unassigned") or "Unassigned").strip(),
            notes=str(raw.get("notes", "") or "").strip(),
        )


@dataclass
class ThresholdWarning:
    """Automated threshold flag highlighting overdue, anomalous, or breached records."""

    code: str
    severity: str  # "Critical" | "Warning"
    request_id: str
    title: str
    detail: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ExecutiveSummary:
    """Aggregated operational and financial summary of hostel maintenance records."""

    generated_at: str
    reference_date: str
    total_requests: int
    pending_count: int
    in_progress_count: int
    resolved_count: int
    open_count: int
    overdue_count: int
    critical_open_count: int
    resolution_rate_pct: float
    avg_open_age_days: float
    avg_resolution_days: float
    total_estimated_cost: float
    pending_estimated_cost: float
    by_category: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    by_block: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    by_priority: Dict[str, int] = field(default_factory=dict)
    monthly_trend: List[Dict[str, Any]] = field(default_factory=list)
    warnings: List[ThresholdWarning] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["warnings"] = [w.to_dict() for w in self.warnings]
        return data


@dataclass
class ImportRowError:
    """Represents a single validation failure during legacy CSV bulk import."""

    row_number: int
    raw_row: Dict[str, Any]
    errors: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class BulkImportResult:
    """Outcome summary for bulk legacy CSV ingestion."""

    total_rows: int
    imported_count: int
    skipped_count: int
    imported_ids: List[str] = field(default_factory=list)
    error_log: List[ImportRowError] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_rows": self.total_rows,
            "imported_count": self.imported_count,
            "skipped_count": self.skipped_count,
            "imported_ids": self.imported_ids,
            "error_log": [e.to_dict() for e in self.error_log],
        }
