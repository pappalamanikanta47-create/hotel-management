"""Interactive ANSI terminal interface for Hostel Maintenance Tracker."""

from __future__ import annotations

import os
from datetime import date, timedelta
from pathlib import Path
from typing import Callable, List, Optional

from hostel_tracker.engine import (
    is_request_overdue,
    query_requests,
    register_request,
    summarize_pending_issues,
    update_request_status,
)
from hostel_tracker.exporter import (
    export_report_to_file,
    render_ascii_category_chart,
    try_generate_matplotlib_chart,
)
from hostel_tracker.importer import import_csv_content
from hostel_tracker.models import (
    CATEGORIES,
    HOSTEL_BLOCKS,
    PRIORITIES,
    SLA_DAYS_BY_PRIORITY,
    STATUSES,
    MaintenanceRequest,
)
from hostel_tracker.storage import (
    DEFAULT_CSV_PATH,
    DEFAULT_JSON_PATH,
    EXPORTS_DIR,
    fetch_campus_advisory_status,
    load_records,
    save_records,
)
from hostel_tracker.validation import (
    prompt_choice,
    prompt_validated,
    validate_description,
    validate_iso_date,
    validate_positive_float,
    validate_reporter_name,
    validate_room_number,
)


class Ansi:
    """ANSI color helpers with automatic NO_COLOR respect."""

    ENABLED = os.environ.get("NO_COLOR", "") == ""
    RESET = "\033[0m" if ENABLED else ""
    BOLD = "\033[1m" if ENABLED else ""
    DIM = "\033[2m" if ENABLED else ""
    BLUE = "\033[34m" if ENABLED else ""
    CYAN = "\033[36m" if ENABLED else ""
    GREEN = "\033[32m" if ENABLED else ""
    YELLOW = "\033[33m" if ENABLED else ""
    RED = "\033[31m" if ENABLED else ""


def _truncate(text: str, width: int) -> str:
    if len(text) <= width:
        return text
    return text[: max(1, width - 3)] + "..."


def print_banner(print_fn: Callable[[str], None] = print) -> None:
    print_fn(f"\n{Ansi.BLUE}{Ansi.BOLD}" + "=" * 78)
    print_fn("  HOSTEL MAINTENANCE TRACKER  |  Campus & Administration Utility")
    print_fn("=" * 78 + f"{Ansi.RESET}")


def print_menu(print_fn: Callable[[str], None] = print) -> None:
    print_fn(f"\n{Ansi.BOLD}Main Menu:{Ansi.RESET}")
    print_fn("  [1] Executive Summary & Pending Overview")
    print_fn("  [2] Register New Maintenance Request")
    print_fn("  [3] Search & Filter Maintenance Records")
    print_fn("  [4] Update Issue Status / Assign Staff")
    print_fn("  [5] View Threshold Warning Indicators")
    print_fn("  [6] Export Summary Reports (Markdown / Audit TXT / CSV)")
    print_fn("  [7] Bulk Import Legacy CSV Dataset")
    print_fn("  [8] Save & Exit")


def render_table(
    records: List[MaintenanceRequest],
    page_size: int = 10,
    input_fn: Callable[[str], str] = input,
    print_fn: Callable[[str], None] = print,
    paginate: bool = True,
) -> None:
    """Render fixed-width formatted terminal tables with pagination breaks."""
    if not records:
        print_fn(f"  {Ansi.DIM}No matching maintenance requests found.{Ansi.RESET}")
        return

    header = (
        f"{'ID':<14} | {'Block':<10} | {'Room':<6} | {'Category':<18} | "
        f"{'Priority':<8} | {'Status':<11} | {'Due Date':<10} | {'Cost':>9}"
    )
    rule = "-" * len(header)
    total_pages = (len(records) + page_size - 1) // page_size

    for page_idx in range(total_pages):
        start = page_idx * page_size
        chunk = records[start : start + page_size]
        print_fn(f"\n{Ansi.BOLD}{header}{Ansi.RESET}")
        print_fn(rule)
        for rec in chunk:
            overdue_marker = "!" if is_request_overdue(rec) else " "
            color = (
                Ansi.RED
                if is_request_overdue(rec)
                else (Ansi.GREEN if rec.status == "Resolved" else Ansi.YELLOW)
            )
            row_str = (
                f"{rec.request_id:<14} | {_truncate(rec.hostel_block, 10):<10} | "
                f"{rec.room_number:<6} | {_truncate(rec.category, 18):<18} | "
                f"{rec.priority:<8} | {color}{rec.status:<11}{Ansi.RESET} | "
                f"{rec.due_date:<10}{overdue_marker}| ${rec.estimated_cost:>8,.2f}"
            )
            print_fn(row_str)
            print_fn(f"  {Ansi.DIM}Desc: {_truncate(rec.description, 74)} (By: {rec.reporter_name}){Ansi.RESET}")
        print_fn(rule)
        print_fn(f"  Showing {start + 1}-{start + len(chunk)} of {len(records)} record(s) [Page {page_idx + 1}/{total_pages}]")

        if paginate and page_idx < total_pages - 1:
            choice = input_fn("  Press Enter for next page, or 'q' to return to menu: ").strip().lower()
            if choice == "q":
                break


def handle_executive_summary(
    records: List[MaintenanceRequest],
    print_fn: Callable[[str], None] = print,
) -> None:
    summary = summarize_pending_issues(records)
    print_fn(f"\n{Ansi.BOLD}{Ansi.CYAN}--- EXECUTIVE SUMMARY (Ref Date: {summary.reference_date}) ---{Ansi.RESET}")
    print_fn(
        f"  Total Requests : {summary.total_requests:<6} | "
        f"Pending: {Ansi.YELLOW}{summary.pending_count:<4}{Ansi.RESET} | "
        f"In Progress: {summary.in_progress_count:<4} | "
        f"Resolved: {Ansi.GREEN}{summary.resolved_count:<4}{Ansi.RESET}"
    )
    print_fn(
        f"  Overdue Open   : {Ansi.RED}{summary.overdue_count:<6}{Ansi.RESET} | "
        f"Critical Open: {summary.critical_open_count:<4} | "
        f"Resolution Rate: {summary.resolution_rate_pct:.1f}%"
    )
    print_fn(
        f"  Avg Open Age   : {summary.avg_open_age_days:.1f} days | "
        f"Avg Resolution Time: {summary.avg_resolution_days:.1f} days"
    )
    print_fn(
        f"  Pending Cost   : ${summary.pending_estimated_cost:,.2f} | "
        f"Total Portfolio Cost: ${summary.total_estimated_cost:,.2f}"
    )

    print_fn(f"\n{Ansi.BOLD}  Block Workload:{Ansi.RESET}")
    print_fn(f"  {'Hostel Block':<12} | {'Total':>5} | {'Open':>5} | {'Overdue':>7} | {'Pending Cost':>12}")
    print_fn("  " + "-" * 53)
    for blk, stats in summary.by_block.items():
        print_fn(
            f"  {blk:<12} | {stats['total']:>5} | {stats['open']:>5} | "
            f"{stats['overdue']:>7} | ${stats['pending_cost']:>11,.2f}"
        )

    print_fn("\n" + render_ascii_category_chart(summary))


def handle_register_request(
    records: List[MaintenanceRequest],
    json_path: Path,
    csv_path: Path,
    input_fn: Callable[[str], str] = input,
    print_fn: Callable[[str], None] = print,
) -> None:
    print_fn(f"\n{Ansi.BOLD}{Ansi.CYAN}--- REGISTER NEW MAINTENANCE REQUEST ---{Ansi.RESET}")
    block = prompt_choice("Hostel Block", HOSTEL_BLOCKS, input_fn=input_fn, print_fn=print_fn)
    room = prompt_validated("Room Number (e.g., B-204)", validate_room_number, input_fn=input_fn, print_fn=print_fn)
    category = prompt_choice("Issue Category", CATEGORIES, input_fn=input_fn, print_fn=print_fn)
    priority = prompt_choice("Priority Level", PRIORITIES, input_fn=input_fn, print_fn=print_fn, default="Medium")
    description = prompt_validated("Issue Description (8-280 chars)", validate_description, input_fn=input_fn, print_fn=print_fn)
    reporter = prompt_validated("Reporter Name", validate_reporter_name, input_fn=input_fn, print_fn=print_fn)

    today_str = date.today().isoformat()
    reported_date = prompt_validated(
        "Reported Date (YYYY-MM-DD)",
        lambda raw: validate_iso_date(raw, "Reported date"),
        input_fn=input_fn,
        print_fn=print_fn,
        default=today_str,
    )
    suggested_due = (
        date.fromisoformat(reported_date) + timedelta(days=SLA_DAYS_BY_PRIORITY[priority])
    ).isoformat()
    due_date = prompt_validated(
        "Target Due Date (YYYY-MM-DD)",
        lambda raw: validate_iso_date(raw, "Due date", min_date=reported_date),
        input_fn=input_fn,
        print_fn=print_fn,
        default=suggested_due,
    )
    estimated_cost = prompt_validated(
        "Estimated Repair Cost (USD)",
        lambda raw: validate_positive_float(raw, "Estimated cost"),
        input_fn=input_fn,
        print_fn=print_fn,
        default="0.00",
    )
    assigned_staff = input_fn("Assigned Technician [Unassigned]: ").strip() or "Unassigned"

    ok, created, errors = register_request(
        records,
        {
            "hostel_block": block,
            "room_number": room,
            "category": category,
            "priority": priority,
            "status": "Pending",
            "description": description,
            "reporter_name": reporter,
            "reported_date": reported_date,
            "due_date": due_date,
            "estimated_cost": estimated_cost,
            "assigned_staff": assigned_staff,
        },
    )
    if ok and created:
        save_records(records, json_path=json_path, csv_path=csv_path)
        print_fn(
            f"\n{Ansi.GREEN}  [Saved] Registered {created.request_id} for {created.hostel_block} Room {created.room_number}.{Ansi.RESET}"
        )
    else:
        print_fn(f"\n{Ansi.RED}  [Error] Could not register request: {errors}{Ansi.RESET}")


def handle_search_records(
    records: List[MaintenanceRequest],
    input_fn: Callable[[str], str] = input,
    print_fn: Callable[[str], None] = print,
) -> None:
    print_fn(f"\n{Ansi.BOLD}{Ansi.CYAN}--- SEARCH & FILTER RECORDS ---{Ansi.RESET}")
    keyword = input_fn("Keyword (ID, room, reporter, description — leave blank for all): ").strip()
    cat_opts = ("All",) + CATEGORIES
    category = prompt_choice("Category Filter", cat_opts, input_fn=input_fn, print_fn=print_fn, default="All")
    status_opts = ("All", "Open") + STATUSES
    status = prompt_choice("Status Filter", status_opts, input_fn=input_fn, print_fn=print_fn, default="All")
    matches = query_requests(records, keyword=keyword, category=category, status=status)
    render_table(matches, page_size=10, input_fn=input_fn, print_fn=print_fn)


def handle_update_status(
    records: List[MaintenanceRequest],
    json_path: Path,
    csv_path: Path,
    input_fn: Callable[[str], str] = input,
    print_fn: Callable[[str], None] = print,
) -> None:
    print_fn(f"\n{Ansi.BOLD}{Ansi.CYAN}--- UPDATE REQUEST STATUS ---{Ansi.RESET}")
    req_id = input_fn("Enter Request ID (e.g., HMT-2026-0001): ").strip()
    if not req_id:
        print_fn("  [Cancelled] Request ID is required.")
        return
    new_status = prompt_choice("New Status", STATUSES, input_fn=input_fn, print_fn=print_fn)
    staff = input_fn("Assigned Staff (leave blank to keep current): ").strip()
    notes = input_fn("Resolution / Progress Notes (optional): ").strip()
    ok, updated, err = update_request_status(
        records,
        req_id,
        new_status,
        assigned_staff=staff or None,
        notes=notes or None,
    )
    if ok and updated:
        save_records(records, json_path=json_path, csv_path=csv_path)
        print_fn(f"  {Ansi.GREEN}[Updated] {updated.request_id} is now '{updated.status}'.{Ansi.RESET}")
    else:
        print_fn(f"  {Ansi.RED}[Error] {err}{Ansi.RESET}")


def handle_warnings(
    records: List[MaintenanceRequest],
    print_fn: Callable[[str], None] = print,
) -> None:
    summary = summarize_pending_issues(records)
    print_fn(f"\n{Ansi.BOLD}{Ansi.CYAN}--- THRESHOLD WARNING INDICATORS ({len(summary.warnings)}) ---{Ansi.RESET}")
    if not summary.warnings:
        print_fn(f"  {Ansi.GREEN}All SLA, deadline, cost, and block thresholds are nominal.{Ansi.RESET}")
        return
    for w in summary.warnings:
        color = Ansi.RED if w.severity == "Critical" else Ansi.YELLOW
        print_fn(f"  {color}[{w.severity.upper()}]{Ansi.RESET} {w.code} ({w.request_id}) — {w.title}")
        print_fn(f"    {Ansi.DIM}{w.detail}{Ansi.RESET}")


def handle_export(
    records: List[MaintenanceRequest],
    exports_dir: Path,
    input_fn: Callable[[str], str] = input,
    print_fn: Callable[[str], None] = print,
) -> None:
    print_fn(f"\n{Ansi.BOLD}{Ansi.CYAN}--- EXPORT EXECUTIVE REPORTS ---{Ansi.RESET}")
    fmt = prompt_choice("Select Export Format", ("md", "txt", "csv"), input_fn=input_fn, print_fn=print_fn, default="md")
    out_path = export_report_to_file(fmt, records, exports_dir=exports_dir)
    print_fn(f"  {Ansi.GREEN}[Exported] Report written to: {out_path}{Ansi.RESET}")
    if fmt == "md":
        summary = summarize_pending_issues(records)
        chart_path = try_generate_matplotlib_chart(summary, exports_dir=exports_dir)
        if chart_path:
            print_fn(f"  {Ansi.GREEN}[Chart] Matplotlib summary chart saved to: {chart_path}{Ansi.RESET}")


def handle_bulk_import(
    records: List[MaintenanceRequest],
    json_path: Path,
    csv_path: Path,
    input_fn: Callable[[str], str] = input,
    print_fn: Callable[[str], None] = print,
) -> None:
    print_fn(f"\n{Ansi.BOLD}{Ansi.CYAN}--- BULK IMPORT LEGACY CSV ---{Ansi.RESET}")
    raw_path = input_fn("Path to legacy CSV [data/legacy_import_sample.csv]: ").strip()
    target = Path(raw_path or "data/legacy_import_sample.csv")
    if not target.exists():
        print_fn(f"  {Ansi.RED}[Error] File not found: {target}{Ansi.RESET}")
        return
    result = import_csv_content(target.read_text(encoding="utf-8"), records)
    if result.imported_count > 0:
        save_records(records, json_path=json_path, csv_path=csv_path)
    print_fn(
        f"  Processed {result.total_rows} row(s): "
        f"{Ansi.GREEN}{result.imported_count} imported{Ansi.RESET}, "
        f"{Ansi.YELLOW}{result.skipped_count} skipped{Ansi.RESET}."
    )
    if result.error_log:
        print_fn("  Row-by-row Error Log:")
        for err in result.error_log:
            print_fn(f"    Row {err.row_number}: {'; '.join(err.errors)}")


def run_cli(
    json_path: Path = DEFAULT_JSON_PATH,
    csv_path: Path = DEFAULT_CSV_PATH,
    exports_dir: Path = EXPORTS_DIR,
    input_fn: Callable[[str], str] = input,
    print_fn: Callable[[str], None] = print,
) -> None:
    """Launch the interactive terminal application loop."""
    print_banner(print_fn=print_fn)
    advisory = fetch_campus_advisory_status()
    print_fn(
        f"  Campus Advisory ({advisory['source']}): {advisory['campus_alert_level']} | "
        f"Hours: {advisory['maintenance_window']}"
    )

    records, notices = load_records(json_path=json_path, csv_path=csv_path)
    for notice in notices:
        print_fn(f"  {Ansi.YELLOW}[Storage Notice] {notice}{Ansi.RESET}")
    print_fn(f"  Loaded {len(records)} maintenance request(s) from local storage.")

    while True:
        print_menu(print_fn=print_fn)
        try:
            choice = input_fn("\nSelect an option (1-8): ").strip()
        except (EOFError, KeyboardInterrupt):
            save_records(records, json_path=json_path, csv_path=csv_path)
            print_fn("\n  Session saved. Exiting Hostel Maintenance Tracker.")
            break

        if choice == "1":
            handle_executive_summary(records, print_fn=print_fn)
        elif choice == "2":
            handle_register_request(records, json_path, csv_path, input_fn=input_fn, print_fn=print_fn)
        elif choice == "3":
            handle_search_records(records, input_fn=input_fn, print_fn=print_fn)
        elif choice == "4":
            handle_update_status(records, json_path, csv_path, input_fn=input_fn, print_fn=print_fn)
        elif choice == "5":
            handle_warnings(records, print_fn=print_fn)
        elif choice == "6":
            handle_export(records, exports_dir, input_fn=input_fn, print_fn=print_fn)
        elif choice == "7":
            handle_bulk_import(records, json_path, csv_path, input_fn=input_fn, print_fn=print_fn)
        elif choice == "8":
            save_records(records, json_path=json_path, csv_path=csv_path)
            print_fn(f"\n{Ansi.GREEN}  All changes persisted to JSON and CSV. Goodbye!{Ansi.RESET}\n")
            break
        else:
            print_fn(f"  {Ansi.RED}[Validation Error] Please enter a menu number from 1 to 8.{Ansi.RESET}")
