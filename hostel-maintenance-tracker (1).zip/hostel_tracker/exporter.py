"""Multi-format summary exporter (Markdown, Plain-Text Audit Log, CSV, and optional chart)."""

from __future__ import annotations

import csv
import io
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from hostel_tracker.engine import is_request_overdue, summarize_pending_issues
from hostel_tracker.models import ExecutiveSummary, MaintenanceRequest
from hostel_tracker.storage import CSV_FIELDNAMES, EXPORTS_DIR


def render_markdown_report(
    records: List[MaintenanceRequest],
    summary: Optional[ExecutiveSummary] = None,
) -> str:
    """Generate a structured Markdown executive summary report."""
    s = summary or summarize_pending_issues(records)
    lines: List[str] = [
        "# Hostel Maintenance Tracker — Executive Summary",
        "",
        f"- **Generated:** {s.generated_at}",
        f"- **Reference Date:** {s.reference_date}",
        f"- **Total Requests:** {s.total_requests}",
        f"- **Pending:** {s.pending_count} | **In Progress:** {s.in_progress_count} | **Resolved:** {s.resolved_count}",
        f"- **Overdue Open Requests:** {s.overdue_count} | **Critical Open:** {s.critical_open_count}",
        f"- **Resolution Rate:** {s.resolution_rate_pct:.1f}%",
        f"- **Average Open Age:** {s.avg_open_age_days:.1f} days | **Average Resolution Time:** {s.avg_resolution_days:.1f} days",
        f"- **Pending Estimated Cost:** ${s.pending_estimated_cost:,.2f} (Total: ${s.total_estimated_cost:,.2f})",
        "",
        "## Category Breakdown",
        "",
        "| Category | Total | Open | Overdue | Resolved | Est. Cost |",
        "| --- | ---: | ---: | ---: | ---: | ---: |",
    ]

    for cat, stats in s.by_category.items():
        lines.append(
            f"| {cat} | {stats['total']} | {stats['open']} | {stats['overdue']} | {stats['resolved']} | ${stats['cost']:,.2f} |"
        )

    lines.extend(
        [
            "",
            "## Hostel Block Workload",
            "",
            "| Hostel Block | Total | Open | Overdue | Resolved | Pending Cost |",
            "| --- | ---: | ---: | ---: | ---: | ---: |",
        ]
    )
    for blk, stats in s.by_block.items():
        lines.append(
            f"| {blk} | {stats['total']} | {stats['open']} | {stats['overdue']} | {stats['resolved']} | ${stats['pending_cost']:,.2f} |"
        )

    lines.extend(["", "## Threshold Warning Indicators", ""])
    if s.warnings:
        for w in s.warnings:
            lines.append(f"- **[{w.severity.upper()}] {w.code} ({w.request_id}):** {w.title} — {w.detail}")
    else:
        lines.append("- No threshold warnings detected.")

    open_items = [r for r in records if r.status != "Resolved"]
    lines.extend(
        [
            "",
            f"## Active Unresolved Issues ({len(open_items)})",
            "",
            "| ID | Block | Room | Category | Priority | Status | Due Date | Cost |",
            "| --- | --- | --- | --- | --- | --- | --- | ---: |",
        ]
    )
    for r in open_items[:25]:
        lines.append(
            f"| {r.request_id} | {r.hostel_block} | {r.room_number} | {r.category} | {r.priority} | {r.status} | {r.due_date} | ${r.estimated_cost:,.2f} |"
        )

    return "\n".join(lines) + "\n"


def render_audit_log(
    records: List[MaintenanceRequest],
    summary: Optional[ExecutiveSummary] = None,
) -> str:
    """Generate a plain-text chronological audit log for administrative archiving."""
    s = summary or summarize_pending_issues(records)
    divider = "=" * 78
    sub_divider = "-" * 78
    lines: List[str] = [
        divider,
        "HOSTEL MAINTENANCE TRACKER — ADMINISTRATIVE AUDIT LOG",
        f"TIMESTAMP: {s.generated_at} | REF DATE: {s.reference_date}",
        divider,
        f"TOTAL={s.total_requests}  PENDING={s.pending_count}  IN_PROGRESS={s.in_progress_count}  RESOLVED={s.resolved_count}",
        f"OVERDUE={s.overdue_count}  CRITICAL_OPEN={s.critical_open_count}  PENDING_COST=${s.pending_estimated_cost:,.2f}",
        sub_divider,
        "THRESHOLD WARNINGS:",
    ]
    if s.warnings:
        for w in s.warnings:
            lines.append(f"  [{w.severity.upper()}] {w.request_id:<14} {w.code:<22} {w.title}")
    else:
        lines.append("  [NONE] All thresholds nominal.")

    lines.append(sub_divider)
    lines.append("RECORD LEDGER:")
    for r in sorted(records, key=lambda x: x.reported_date, reverse=True):
        overdue_tag = " [OVERDUE]" if is_request_overdue(r) else ""
        lines.append(
            f"  {r.reported_date} | {r.request_id} | {r.hostel_block:<10} | {r.room_number:<6} | "
            f"{r.category:<18} | {r.priority:<8} | {r.status:<11}{overdue_tag} | ${r.estimated_cost:>8.2f} | {r.description}"
        )
    lines.append(divider)
    return "\n".join(lines) + "\n"


def render_csv_report(records: List[MaintenanceRequest]) -> str:
    """Serialize maintenance records into standardized CSV format."""
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=CSV_FIELDNAMES)
    writer.writeheader()
    for r in records:
        row = r.to_dict()
        row["resolved_date"] = row["resolved_date"] or ""
        writer.writerow(row)
    return buf.getvalue()


def render_ascii_category_chart(summary: ExecutiveSummary) -> str:
    """Render a clean ASCII bar chart of open vs resolved issues by category."""
    lines = ["Category Open vs. Resolved Distribution:"]
    max_total = max((v["total"] for v in summary.by_category.values()), default=1)
    bar_width = 24
    for cat, stats in summary.by_category.items():
        open_len = round((stats["open"] / max_total) * bar_width)
        res_len = round((stats["resolved"] / max_total) * bar_width)
        bar = ("#" * open_len) + ("." * res_len)
        lines.append(
            f"  {cat:<19} | {bar:<24} | Open: {stats['open']:>2}  Resolved: {stats['resolved']:>2}"
        )
    lines.append("  Legend: '#' = Unresolved (Pending/In Progress), '.' = Resolved")
    return "\n".join(lines)


def export_report_to_file(
    fmt: str,
    records: List[MaintenanceRequest],
    exports_dir: Path = EXPORTS_DIR,
) -> Path:
    """Write Markdown, Audit TXT, or CSV report to exports/ and return the output path."""
    exports_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    fmt_lower = fmt.strip().lower()

    if fmt_lower in ("md", "markdown"):
        content = render_markdown_report(records)
        out_path = exports_dir / f"maintenance_summary_{stamp}.md"
    elif fmt_lower in ("txt", "audit", "log"):
        content = render_audit_log(records)
        out_path = exports_dir / f"maintenance_audit_{stamp}.txt"
    elif fmt_lower == "csv":
        content = render_csv_report(records)
        out_path = exports_dir / f"maintenance_report_{stamp}.csv"
    else:
        raise ValueError(f"Unsupported export format '{fmt}'. Choose md, txt, or csv.")

    out_path.write_text(content, encoding="utf-8")
    return out_path


def try_generate_matplotlib_chart(
    summary: ExecutiveSummary,
    exports_dir: Path = EXPORTS_DIR,
) -> Optional[Path]:
    """Optional Matplotlib bar chart export with graceful ImportError fallback."""
    try:
        import matplotlib  # type: ignore

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt  # type: ignore
    except ImportError:
        return None

    exports_dir.mkdir(parents=True, exist_ok=True)
    categories = list(summary.by_category.keys())
    open_counts = [summary.by_category[c]["open"] for c in categories]
    resolved_counts = [summary.by_category[c]["resolved"] for c in categories]

    fig, ax = plt.subplots(figsize=(9, 4.5))
    x = range(len(categories))
    ax.bar(x, open_counts, label="Unresolved", color="#D97706")
    ax.bar(x, resolved_counts, bottom=open_counts, label="Resolved", color="#1D4ED8")
    ax.set_xticks(list(x))
    ax.set_xticklabels(categories, rotation=25, ha="right")
    ax.set_ylabel("Requests")
    ax.set_title("Hostel Maintenance Issues by Category")
    ax.legend()
    fig.tight_layout()

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_path = exports_dir / f"maintenance_chart_{stamp}.png"
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return out_path
