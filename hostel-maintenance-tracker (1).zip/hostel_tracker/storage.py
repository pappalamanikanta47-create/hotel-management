"""Fault-tolerant JSON and CSV persistence with schema validation and recovery."""

from __future__ import annotations

import csv
import json
import shutil
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from hostel_tracker.models import MaintenanceRequest

ROOT_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT_DIR / "data"
EXPORTS_DIR = ROOT_DIR / "exports"
DEFAULT_JSON_PATH = DATA_DIR / "maintenance_requests.json"
DEFAULT_CSV_PATH = DATA_DIR / "maintenance_requests.csv"

CSV_FIELDNAMES: tuple[str, ...] = (
    "request_id",
    "hostel_block",
    "room_number",
    "category",
    "priority",
    "status",
    "description",
    "reporter_name",
    "reported_date",
    "due_date",
    "estimated_cost",
    "resolved_date",
    "assigned_staff",
    "notes",
)

REQUIRED_RECORD_KEYS: tuple[str, ...] = (
    "request_id",
    "hostel_block",
    "room_number",
    "category",
    "priority",
    "status",
    "description",
    "reporter_name",
    "reported_date",
    "due_date",
)


def ensure_data_directories(
    json_path: Path = DEFAULT_JSON_PATH,
    csv_path: Path = DEFAULT_CSV_PATH,
    exports_dir: Path = EXPORTS_DIR,
) -> None:
    """Create data and exports directories if missing."""
    json_path.parent.mkdir(parents=True, exist_ok=True)
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    exports_dir.mkdir(parents=True, exist_ok=True)


def _backup_corrupted_file(file_path: Path) -> Optional[Path]:
    """Preserve corrupted storage files before re-initializing a clean template."""
    if not file_path.exists():
        return None
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = file_path.with_name(f"{file_path.stem}.corrupt_{stamp}{file_path.suffix}")
    try:
        shutil.copy2(file_path, backup_path)
        return backup_path
    except OSError:
        return None


def _is_valid_record_dict(item: Any) -> bool:
    if not isinstance(item, dict):
        return False
    return all(key in item and str(item[key]).strip() != "" for key in REQUIRED_RECORD_KEYS)


def save_records(
    records: List[MaintenanceRequest],
    json_path: Path = DEFAULT_JSON_PATH,
    csv_path: Path = DEFAULT_CSV_PATH,
) -> None:
    """Persist all maintenance requests atomically to both JSON and CSV files."""
    ensure_data_directories(json_path, csv_path)

    payload = {
        "schema_version": "1.0",
        "updated_at": datetime.now().isoformat(timespec="seconds"),
        "record_count": len(records),
        "records": [r.to_dict() for r in records],
    }

    tmp_json = json_path.with_suffix(".json.tmp")
    with tmp_json.open("w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2, ensure_ascii=False)
    tmp_json.replace(json_path)

    tmp_csv = csv_path.with_suffix(".csv.tmp")
    with tmp_csv.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=CSV_FIELDNAMES)
        writer.writeheader()
        for record in records:
            row = record.to_dict()
            row["resolved_date"] = row["resolved_date"] or ""
            writer.writerow(row)
    tmp_csv.replace(csv_path)


def load_records(
    json_path: Path = DEFAULT_JSON_PATH,
    csv_path: Path = DEFAULT_CSV_PATH,
) -> Tuple[List[MaintenanceRequest], List[str]]:
    """
    Load maintenance records from JSON (primary) with CSV fallback and corruption recovery.

    Returns (records, recovery_notices).
    """
    ensure_data_directories(json_path, csv_path)
    notices: List[str] = []

    if json_path.exists():
        try:
            with json_path.open("r", encoding="utf-8") as fh:
                raw_data = json.load(fh)

            if isinstance(raw_data, dict) and isinstance(raw_data.get("records"), list):
                raw_list = raw_data["records"]
            elif isinstance(raw_data, list):
                raw_list = raw_data
            else:
                raise json.JSONDecodeError("Invalid top-level schema", "", 0)

            valid_records: List[MaintenanceRequest] = []
            skipped = 0
            for entry in raw_list:
                if _is_valid_record_dict(entry):
                    try:
                        valid_records.append(MaintenanceRequest.from_dict(entry))
                    except (TypeError, ValueError):
                        skipped += 1
                else:
                    skipped += 1

            if skipped > 0:
                notices.append(
                    f"Skipped {skipped} malformed record(s) while reading {json_path.name}."
                )
            return valid_records, notices

        except (json.JSONDecodeError, OSError, UnicodeDecodeError) as exc:
            backup = _backup_corrupted_file(json_path)
            notices.append(
                f"Detected corrupted or unreadable {json_path.name} ({exc.__class__.__name__})."
                + (f" Backed up to {backup.name}." if backup else "")
            )

    # Fallback to CSV if JSON is missing or corrupted
    if csv_path.exists():
        try:
            csv_records: List[MaintenanceRequest] = []
            with csv_path.open("r", encoding="utf-8", newline="") as fh:
                reader = csv.DictReader(fh)
                if not reader.fieldnames or not set(REQUIRED_RECORD_KEYS).issubset(
                    set(reader.fieldnames)
                ):
                    raise csv.Error("Missing required CSV columns")
                for row in reader:
                    if _is_valid_record_dict(row):
                        csv_records.append(MaintenanceRequest.from_dict(row))
            save_records(csv_records, json_path=json_path, csv_path=csv_path)
            notices.append(
                f"Recovered {len(csv_records)} record(s) from {csv_path.name} and rebuilt {json_path.name}."
            )
            return csv_records, notices
        except (csv.Error, OSError, UnicodeDecodeError, ValueError) as exc:
            backup_csv = _backup_corrupted_file(csv_path)
            notices.append(
                f"CSV fallback failed ({exc.__class__.__name__})."
                + (f" Backed up to {backup_csv.name}." if backup_csv else "")
            )

    # Create clean empty template if neither file is usable
    save_records([], json_path=json_path, csv_path=csv_path)
    notices.append("Initialized clean empty JSON and CSV storage templates.")
    return [], notices


def fetch_campus_advisory_status(endpoint: Optional[str] = None, timeout: float = 2.5) -> Dict[str, Any]:
    """
    Optional external advisory check using `requests` with graceful fallback.

    Demonstrates resilient handling of ImportError or RequestException when offline.
    """
    local_cache = {
        "source": "local_cache",
        "campus_alert_level": "Standard Operations",
        "maintenance_window": "08:00 - 18:00 Daily",
        "emergency_hotline": "Campus Facilities Ext. 4400",
    }
    if not endpoint:
        return local_cache

    try:
        import requests  # type: ignore
    except ImportError:
        return local_cache

    try:
        resp = requests.get(endpoint, timeout=timeout)
        resp.raise_for_status()
        data = resp.json()
        if isinstance(data, dict):
            return {
                "source": "remote_api",
                "campus_alert_level": str(data.get("campus_alert_level", "Standard Operations")),
                "maintenance_window": str(data.get("maintenance_window", "08:00 - 18:00 Daily")),
                "emergency_hotline": str(data.get("emergency_hotline", "Campus Facilities Ext. 4400")),
            }
    except Exception:
        # Catches RequestException, Timeout, ValueError, etc. and falls back safely
        return local_cache

    return local_cache
