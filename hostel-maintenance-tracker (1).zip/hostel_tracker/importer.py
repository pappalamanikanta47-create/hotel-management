"""Bulk CSV dataset importer with automatic validation and row-by-row error logs."""

from __future__ import annotations

import csv
import io
from typing import Dict, List

from hostel_tracker.engine import generate_next_request_id
from hostel_tracker.models import (
    BulkImportResult,
    ImportRowError,
    MaintenanceRequest,
)
from hostel_tracker.validation import format_validation_errors, validate_request_payload

HEADER_ALIASES: Dict[str, str] = {
    "block": "hostel_block",
    "hostel": "hostel_block",
    "hostel_block": "hostel_block",
    "room": "room_number",
    "room_no": "room_number",
    "room_number": "room_number",
    "category": "category",
    "issue_type": "category",
    "priority": "priority",
    "urgency": "priority",
    "status": "status",
    "description": "description",
    "issue": "description",
    "details": "description",
    "reporter": "reporter_name",
    "reporter_name": "reporter_name",
    "reported_by": "reporter_name",
    "reported_date": "reported_date",
    "date_reported": "reported_date",
    "due_date": "due_date",
    "deadline": "due_date",
    "cost": "estimated_cost",
    "estimated_cost": "estimated_cost",
    "resolved_date": "resolved_date",
    "assigned_staff": "assigned_staff",
    "staff": "assigned_staff",
    "notes": "notes",
    "request_id": "request_id",
}


def _normalize_csv_row(raw_row: Dict[str, str]) -> Dict[str, str]:
    normalized: Dict[str, str] = {}
    for key, val in raw_row.items():
        if key is None:
            continue
        clean_key = key.strip().lower().replace(" ", "_")
        mapped_key = HEADER_ALIASES.get(clean_key, clean_key)
        normalized[mapped_key] = val.strip() if isinstance(val, str) else ""
    return normalized


def import_csv_content(
    csv_text: str,
    records: List[MaintenanceRequest],
) -> BulkImportResult:
    """
    Parse CSV text, validate each row against domain constraints, and append valid records.

    Returns BulkImportResult with imported IDs and detailed row-by-row error logs.
    """
    stripped = csv_text.strip()
    if not stripped:
        return BulkImportResult(
            total_rows=0,
            imported_count=0,
            skipped_count=0,
            error_log=[
                ImportRowError(
                    row_number=0,
                    raw_row={},
                    errors=["CSV input is empty. Provide header row and at least one data row."],
                )
            ],
        )

    reader = csv.DictReader(io.StringIO(stripped))
    if not reader.fieldnames:
        return BulkImportResult(
            total_rows=0,
            imported_count=0,
            skipped_count=0,
            error_log=[
                ImportRowError(
                    row_number=1,
                    raw_row={},
                    errors=["Missing CSV header row."],
                )
            ],
        )

    total_rows = 0
    imported_ids: List[str] = []
    error_log: List[ImportRowError] = []

    for row_index, raw_row in enumerate(reader, start=2):
        total_rows += 1
        normalized = _normalize_csv_row(raw_row)
        ok, cleaned, field_errors = validate_request_payload(normalized)
        if not ok:
            error_log.append(
                ImportRowError(
                    row_number=row_index,
                    raw_row=dict(raw_row),
                    errors=format_validation_errors(field_errors),
                )
            )
            continue

        year = int(cleaned["reported_date"][:4])
        candidate_id = normalized.get("request_id", "")
        if not candidate_id or any(r.request_id == candidate_id for r in records):
            candidate_id = generate_next_request_id(records, year=year)

        new_rec = MaintenanceRequest(
            request_id=candidate_id,
            hostel_block=cleaned["hostel_block"],
            room_number=cleaned["room_number"],
            category=cleaned["category"],
            priority=cleaned["priority"],
            status=cleaned["status"],
            description=cleaned["description"],
            reporter_name=cleaned["reporter_name"],
            reported_date=cleaned["reported_date"],
            due_date=cleaned["due_date"],
            estimated_cost=cleaned["estimated_cost"],
            resolved_date=cleaned["resolved_date"],
            assigned_staff=cleaned["assigned_staff"],
            notes=cleaned["notes"],
        )
        records.insert(0, new_rec)
        imported_ids.append(candidate_id)

    return BulkImportResult(
        total_rows=total_rows,
        imported_count=len(imported_ids),
        skipped_count=len(error_log),
        imported_ids=imported_ids,
        error_log=error_log,
    )
