"""Hostel Maintenance Tracker package for Campus & Administration."""

__version__ = "1.0.0"
__app_name__ = "Hostel Maintenance Tracker"
