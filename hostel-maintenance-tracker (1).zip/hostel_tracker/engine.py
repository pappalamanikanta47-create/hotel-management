"""Core business logic engine for registering, querying, and summarizing maintenance issues."""

from __future__ import annotations

import math
from collections import defaultdict
from datetime import date, datetime
from typing import Any, Dict, List, Optional, Tuple

from hostel_tracker.models import (
    BLOCK_PENDING_THRESHOLD,
    CATEGORIES,
    COST_ANOMALY_THRESHOLD,
    HOSTEL_BLOCKS,
    PRIORITIES,
    STATUSES,
    ExecutiveSummary,
    MaintenanceRequest,
    ThresholdWarning,
)
from hostel_tracker.validation import validate_choice, validate_request_payload


def _parse_date(date_str: Optional[str]) -> Optional[date]:
    if not date_str:
        return None
    try:
        return datetime.strptime(date_str.strip(), "%Y-%m-%d").date()
    except ValueError:
        return None


def generate_next_request_id(
    records: List[MaintenanceRequest],
    year: Optional[int] = None,
) -> str:
    """Generate sequential request ID in the format HMT-YYYY-NNNN."""
    target_year = year or date.today().year
    prefix = f"HMT-{target_year}-"
    max_seq = 0
    for rec in records:
        if rec.request_id.startswith(prefix):
            tail = rec.request_id[len(prefix) :]
            if tail.isdigit():
                max_seq = max(max_seq, int(tail))
    return f"{prefix}{max_seq + 1:04d}"


def register_request(
    records: List[MaintenanceRequest],
    payload: Dict[str, Any],
) -> Tuple[bool, Optional[MaintenanceRequest], Dict[str, str]]:
    """Validate payload, assign sequential ID, and append a new MaintenanceRequest."""
    ok, cleaned, errors = validate_request_payload(payload)
    if not ok:
        return False, None, errors

    rep_date = _parse_date(cleaned["reported_date"]) or date.today()
    req_id = payload.get("request_id")
    if not req_id or any(r.request_id == req_id for r in records):
        req_id = generate_next_request_id(records, year=rep_date.year)

    record = MaintenanceRequest(
        request_id=req_id,
        hostel_block=cleaned["hostel_block"],
        room_number=cleaned["room_number"],
        category=cleaned["category"],
        priority=cleaned["priority"],
        status=cleaned["status"],
        description=cleaned["description"],
        reporter_name=cleaned["reporter_name"],
        reported_date=cleaned["reported_date"],
        due_date=cleaned["due_date"],
        estimated_cost=cleaned["estimated_cost"],
        resolved_date=cleaned["resolved_date"],
        assigned_staff=cleaned["assigned_staff"],
        notes=cleaned["notes"],
    )
    records.insert(0, record)
    return True, record, {}


def update_request_status(
    records: List[MaintenanceRequest],
    request_id: str,
    new_status: str,
    assigned_staff: Optional[str] = None,
    notes: Optional[str] = None,
    resolved_date: Optional[str] = None,
) -> Tuple[bool, Optional[MaintenanceRequest], str]:
    """Update status, staff assignment, or resolution date for an existing request."""
    ok, canonical_status, err = validate_choice(new_status, STATUSES, "Status")
    if not ok:
        return False, None, err

    target = next((r for r in records if r.request_id.upper() == request_id.strip().upper()), None)
    if target is None:
        return False, None, f"Maintenance request '{request_id}' not found."

    target.status = canonical_status
    if assigned_staff is not None and assigned_staff.strip():
        target.assigned_staff = assigned_staff.strip()
    if notes is not None and notes.strip():
        target.notes = notes.strip()

    if canonical_status == "Resolved":
        target.resolved_date = resolved_date or date.today().isoformat()
    else:
        target.resolved_date = None

    return True, target, ""


def is_request_overdue(
    record: MaintenanceRequest,
    reference_date: Optional[date] = None,
) -> bool:
    """Return True if an open request has passed its due_date relative to reference_date."""
    if record.status == "Resolved":
        return False
    ref = reference_date or date.today()
    due = _parse_date(record.due_date)
    if due is None:
        return False
    return due < ref


def days_open(
    record: MaintenanceRequest,
    reference_date: Optional[date] = None,
) -> int:
    """Compute non-negative age in days since reported_date."""
    rep = _parse_date(record.reported_date)
    if rep is None:
        return 0
    end = _parse_date(record.resolved_date) if record.status == "Resolved" else (reference_date or date.today())
    if end is None:
        end = reference_date or date.today()
    return max(0, (end - rep).days)


def query_requests(
    records: List[MaintenanceRequest],
    keyword: str = "",
    category: str = "All",
    block: str = "All",
    status: str = "All",
    priority: str = "All",
    overdue_only: bool = False,
    reference_date: Optional[date] = None,
) -> List[MaintenanceRequest]:
    """Filter records by keyword and structured attributes."""
    kw = keyword.strip().lower()
    ref = reference_date or date.today()

    results: List[MaintenanceRequest] = []
    for rec in records:
        if category and category != "All" and rec.category.lower() != category.lower():
            continue
        if block and block != "All" and rec.hostel_block.lower() != block.lower():
            continue
        if status and status != "All":
            if status == "Open":
                if rec.status == "Resolved":
                    continue
            elif rec.status.lower() != status.lower():
                continue
        if priority and priority != "All" and rec.priority.lower() != priority.lower():
            continue
        if overdue_only and not is_request_overdue(rec, ref):
            continue
        if kw:
            haystack = " ".join(
                [
                    rec.request_id,
                    rec.hostel_block,
                    rec.room_number,
                    rec.category,
                    rec.description,
                    rec.reporter_name,
                    rec.assigned_staff,
                    rec.notes,
                ]
            ).lower()
            if kw not in haystack:
                continue
        results.append(rec)

    return results


def detect_threshold_warnings(
    records: List[MaintenanceRequest],
    reference_date: Optional[date] = None,
) -> List[ThresholdWarning]:
    """Identify overdue deadlines, SLA breaches, cost anomalies, duplicates, and block overload."""
    ref = reference_date or date.today()
    warnings: List[ThresholdWarning] = []

    open_room_cat: Dict[Tuple[str, str, str], List[MaintenanceRequest]] = defaultdict(list)
    open_by_block: Dict[str, int] = defaultdict(int)

    for rec in records:
        age = days_open(rec, ref)
        if rec.status != "Resolved":
            open_by_block[rec.hostel_block] += 1
            open_room_cat[(rec.hostel_block, rec.room_number, rec.category)].append(rec)

            due = _parse_date(rec.due_date)
            if due and due < ref:
                overdue_days = (ref - due).days
                severity = "Critical" if rec.priority in ("Critical", "High") or overdue_days >= 5 else "Warning"
                warnings.append(
                    ThresholdWarning(
                        code="OVERDUE_DEADLINE",
                        severity=severity,
                        request_id=rec.request_id,
                        title=f"Overdue {rec.priority} issue in {rec.hostel_block} ({rec.room_number})",
                        detail=f"Due {rec.due_date} ({overdue_days} day(s) overdue). Status: {rec.status}.",
                    )
                )

            if rec.priority == "Critical" and age >= 2:
                warnings.append(
                    ThresholdWarning(
                        code="CRITICAL_SLA_BREACH",
                        severity="Critical",
                        request_id=rec.request_id,
                        title=f"Critical SLA breach in {rec.room_number}",
                        detail=f"Critical request open for {age} days (1-day SLA limit exceeded).",
                    )
                )

        if rec.estimated_cost >= COST_ANOMALY_THRESHOLD:
            warnings.append(
                ThresholdWarning(
                    code="COST_ANOMALY",
                    severity="Warning",
                    request_id=rec.request_id,
                    title=f"High-cost estimate (${rec.estimated_cost:,.2f}) on {rec.request_id}",
                    detail=f"Exceeds ${COST_ANOMALY_THRESHOLD:,.2f} single-ticket threshold ({rec.category} · {rec.hostel_block}).",
                )
            )

    for (blk, room, cat), group in open_room_cat.items():
        if len(group) > 1:
            ids = ", ".join(r.request_id for r in group)
            warnings.append(
                ThresholdWarning(
                    code="DUPLICATE_OPEN_ISSUE",
                    severity="Warning",
                    request_id=group[0].request_id,
                    title=f"Repeated open {cat} tickets in {blk} {room}",
                    detail=f"{len(group)} active tickets share room/category ({ids}).",
                )
            )

    for blk, count in open_by_block.items():
        if count >= BLOCK_PENDING_THRESHOLD:
            warnings.append(
                ThresholdWarning(
                    code="BLOCK_OVERLOAD",
                    severity="Warning",
                    request_id=blk,
                    title=f"{blk} pending workload threshold reached",
                    detail=f"{count} unresolved requests (threshold: {BLOCK_PENDING_THRESHOLD}).",
                )
            )

    severity_rank = {"Critical": 0, "Warning": 1}
    warnings.sort(key=lambda w: (severity_rank.get(w.severity, 2), w.code, w.request_id))
    return warnings


def summarize_pending_issues(
    records: List[MaintenanceRequest],
    reference_date: Optional[date] = None,
) -> ExecutiveSummary:
    """Compute comprehensive executive summary metrics, breakdowns, trends, and warnings."""
    ref = reference_date or date.today()
    total = len(records)

    pending_count = sum(1 for r in records if r.status == "Pending")
    in_progress_count = sum(1 for r in records if r.status == "In Progress")
    resolved_count = sum(1 for r in records if r.status == "Resolved")
    open_count = pending_count + in_progress_count
    overdue_count = sum(1 for r in records if is_request_overdue(r, ref))
    critical_open_count = sum(
        1 for r in records if r.status != "Resolved" and r.priority == "Critical"
    )

    resolution_rate = round((resolved_count / total) * 100, 1) if total > 0 else 0.0

    open_ages = [days_open(r, ref) for r in records if r.status != "Resolved"]
    resolved_ages = [days_open(r, ref) for r in records if r.status == "Resolved"]

    avg_open_age = round(math.fsum(open_ages) / len(open_ages), 1) if open_ages else 0.0
    avg_res_days = round(math.fsum(resolved_ages) / len(resolved_ages), 1) if resolved_ages else 0.0

    total_cost = round(math.fsum(r.estimated_cost for r in records), 2)
    pending_cost = round(
        math.fsum(r.estimated_cost for r in records if r.status != "Resolved"), 2
    )

    by_category: Dict[str, Dict[str, Any]] = {}
    for cat in CATEGORIES:
        cat_items = [r for r in records if r.category == cat]
        if not cat_items:
            continue
        by_category[cat] = {
            "total": len(cat_items),
            "pending": sum(1 for r in cat_items if r.status == "Pending"),
            "in_progress": sum(1 for r in cat_items if r.status == "In Progress"),
            "resolved": sum(1 for r in cat_items if r.status == "Resolved"),
            "open": sum(1 for r in cat_items if r.status != "Resolved"),
            "overdue": sum(1 for r in cat_items if is_request_overdue(r, ref)),
            "cost": round(math.fsum(r.estimated_cost for r in cat_items), 2),
        }

    by_block: Dict[str, Dict[str, Any]] = {}
    for blk in HOSTEL_BLOCKS:
        blk_items = [r for r in records if r.hostel_block == blk]
        if not blk_items:
            continue
        by_block[blk] = {
            "total": len(blk_items),
            "open": sum(1 for r in blk_items if r.status != "Resolved"),
            "overdue": sum(1 for r in blk_items if is_request_overdue(r, ref)),
            "resolved": sum(1 for r in blk_items if r.status == "Resolved"),
            "pending_cost": round(
                math.fsum(r.estimated_cost for r in blk_items if r.status != "Resolved"),
                2,
            ),
        }

    by_priority: Dict[str, int] = {
        p: sum(1 for r in records if r.status != "Resolved" and r.priority == p)
        for p in PRIORITIES
    }

    month_buckets: Dict[str, Dict[str, int]] = defaultdict(
        lambda: {"reported": 0, "resolved": 0, "open": 0}
    )
    for rec in records:
        month_key = rec.reported_date[:7] if len(rec.reported_date) >= 7 else "Unknown"
        month_buckets[month_key]["reported"] += 1
        if rec.status == "Resolved":
            month_buckets[month_key]["resolved"] += 1
        else:
            month_buckets[month_key]["open"] += 1

    monthly_trend = [
        {"month": month, **counts}
        for month, counts in sorted(month_buckets.items())
    ]

    warnings = detect_threshold_warnings(records, ref)

    return ExecutiveSummary(
        generated_at=datetime.now().isoformat(timespec="seconds"),
        reference_date=ref.isoformat(),
        total_requests=total,
        pending_count=pending_count,
        in_progress_count=in_progress_count,
        resolved_count=resolved_count,
        open_count=open_count,
        overdue_count=overdue_count,
        critical_open_count=critical_open_count,
        resolution_rate_pct=resolution_rate,
        avg_open_age_days=avg_open_age,
        avg_resolution_days=avg_res_days,
        total_estimated_cost=total_cost,
        pending_estimated_cost=pending_cost,
        by_category=by_category,
        by_block=by_block,
        by_priority=by_priority,
        monthly_trend=monthly_trend,
        warnings=warnings,
    )
