"""Defensive input validation and sanitization routines."""

from __future__ import annotations

import re
from datetime import date, datetime
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from hostel_tracker.models import (
    CATEGORIES,
    HOSTEL_BLOCKS,
    MAX_ESTIMATED_COST,
    PRIORITIES,
    STATUSES,
)

ROOM_PATTERN = re.compile(r"^(?:[A-Z]{1,3}-?)?\d{2,4}[A-Z]?$")
NAME_PATTERN = re.compile(r"^[A-Za-z][A-Za-z\s.'-]{1,59}$")


def sanitize_text(value: Any) -> str:
    """Collapse internal whitespace and strip control characters."""
    if value is None:
        return ""
    cleaned = re.sub(r"[\x00-\x1f\x7f]+", " ", str(value))
    return re.sub(r"\s+", " ", cleaned).strip()


def validate_room_number(raw: Any) -> Tuple[bool, str, str]:
    """Validate and normalize a hostel room code (e.g., A-104, 208, N-302B)."""
    text = sanitize_text(raw).upper()
    if not text:
        return False, "", "Room number is required (e.g., A-104 or 205)."
    if not ROOM_PATTERN.match(text):
        return (
            False,
            "",
            "Room number must be 2-4 digits with optional block prefix (e.g., B-204, 305).",
        )
    return True, text, ""


def validate_choice(
    raw: Any,
    allowed: Sequence[str],
    field_label: str,
) -> Tuple[bool, str, str]:
    """Case-insensitive choice validator returning canonical option casing."""
    text = sanitize_text(raw)
    if not text:
        return False, "", f"{field_label} is required. Allowed: {', '.join(allowed)}."
    lookup = {item.lower(): item for item in allowed}
    canonical = lookup.get(text.lower())
    if canonical is None:
        return (
            False,
            "",
            f"Invalid {field_label} '{text}'. Choose one of: {', '.join(allowed)}.",
        )
    return True, canonical, ""


def validate_positive_float(
    raw: Any,
    field_label: str = "Estimated cost",
    minimum: float = 0.0,
    maximum: float = MAX_ESTIMATED_COST,
) -> Tuple[bool, float, str]:
    """Validate finite numeric value within domain bounds."""
    if raw is None or (isinstance(raw, str) and not raw.strip()):
        return False, 0.0, f"{field_label} is required and must be a number."
    try:
        cleaned = str(raw).replace(",", "").replace("$", "").strip()
        val = float(cleaned)
    except (TypeError, ValueError):
        return False, 0.0, f"{field_label} must be a valid numeric amount."
    if val != val or val in (float("inf"), float("-inf")):
        return False, 0.0, f"{field_label} must be a finite number."
    if val < minimum or val > maximum:
        return (
            False,
            0.0,
            f"{field_label} must be between {minimum:.2f} and {maximum:,.2f}.",
        )
    return True, round(val, 2), ""


def validate_iso_date(
    raw: Any,
    field_label: str = "Date",
    min_date: Optional[str] = None,
) -> Tuple[bool, str, str]:
    """Validate YYYY-MM-DD calendar date and optional lower bound."""
    text = sanitize_text(raw)
    if not text:
        return False, "", f"{field_label} is required (format YYYY-MM-DD)."
    try:
        parsed = datetime.strptime(text, "%Y-%m-%d").date()
    except ValueError:
        return False, "", f"{field_label} '{text}' must use YYYY-MM-DD format."
    if min_date:
        try:
            floor = datetime.strptime(min_date, "%Y-%m-%d").date()
            if parsed < floor:
                return (
                    False,
                    "",
                    f"{field_label} ({text}) cannot be earlier than {min_date}.",
                )
        except ValueError:
            pass
    return True, parsed.isoformat(), ""


def validate_reporter_name(raw: Any) -> Tuple[bool, str, str]:
    """Validate reporter / resident / warden name."""
    text = sanitize_text(raw)
    if not text:
        return False, "", "Reporter name is required."
    if len(text) < 2 or len(text) > 60:
        return False, "", "Reporter name must be between 2 and 60 characters."
    if not NAME_PATTERN.match(text):
        return (
            False,
            "",
            "Reporter name must start with a letter and contain only letters, spaces, periods, or hyphens.",
        )
    return True, text, ""


def validate_description(raw: Any) -> Tuple[bool, str, str]:
    """Validate maintenance issue description."""
    text = sanitize_text(raw)
    if not text:
        return False, "", "Issue description is required."
    if len(text) < 8:
        return False, "", "Description must be at least 8 characters long."
    if len(text) > 280:
        return False, "", "Description cannot exceed 280 characters."
    return True, text, ""


def validate_request_payload(payload: Dict[str, Any]) -> Tuple[bool, Dict[str, Any], Dict[str, str]]:
    """
    Validate and sanitize a complete maintenance request payload.

    Returns (is_valid, cleaned_payload, field_errors).
    """
    errors: Dict[str, str] = {}
    cleaned: Dict[str, Any] = {}

    ok_block, block_val, err_block = validate_choice(
        payload.get("hostel_block"), HOSTEL_BLOCKS, "Hostel block"
    )
    if ok_block:
        cleaned["hostel_block"] = block_val
    else:
        errors["hostel_block"] = err_block

    ok_room, room_val, err_room = validate_room_number(payload.get("room_number"))
    if ok_room:
        cleaned["room_number"] = room_val
    else:
        errors["room_number"] = err_room

    ok_cat, cat_val, err_cat = validate_choice(
        payload.get("category"), CATEGORIES, "Category"
    )
    if ok_cat:
        cleaned["category"] = cat_val
    else:
        errors["category"] = err_cat

    ok_pri, pri_val, err_pri = validate_choice(
        payload.get("priority"), PRIORITIES, "Priority"
    )
    if ok_pri:
        cleaned["priority"] = pri_val
    else:
        errors["priority"] = err_pri

    raw_status = payload.get("status") or "Pending"
    ok_status, status_val, err_status = validate_choice(raw_status, STATUSES, "Status")
    if ok_status:
        cleaned["status"] = status_val
    else:
        errors["status"] = err_status

    ok_desc, desc_val, err_desc = validate_description(payload.get("description"))
    if ok_desc:
        cleaned["description"] = desc_val
    else:
        errors["description"] = err_desc

    ok_rep, rep_val, err_rep = validate_reporter_name(payload.get("reporter_name"))
    if ok_rep:
        cleaned["reporter_name"] = rep_val
    else:
        errors["reporter_name"] = err_rep

    reported_raw = payload.get("reported_date") or date.today().isoformat()
    ok_rep_date, rep_date_val, err_rep_date = validate_iso_date(
        reported_raw, "Reported date"
    )
    if ok_rep_date:
        cleaned["reported_date"] = rep_date_val
    else:
        errors["reported_date"] = err_rep_date

    due_raw = payload.get("due_date")
    ok_due, due_val, err_due = validate_iso_date(
        due_raw,
        "Due date",
        min_date=rep_date_val if ok_rep_date else None,
    )
    if ok_due:
        cleaned["due_date"] = due_val
    else:
        errors["due_date"] = err_due

    ok_cost, cost_val, err_cost = validate_positive_float(
        payload.get("estimated_cost"), "Estimated cost"
    )
    if ok_cost:
        cleaned["estimated_cost"] = cost_val
    else:
        errors["estimated_cost"] = err_cost

    cleaned["assigned_staff"] = sanitize_text(payload.get("assigned_staff")) or "Unassigned"
    cleaned["notes"] = sanitize_text(payload.get("notes"))

    resolved_raw = payload.get("resolved_date")
    if cleaned.get("status") == "Resolved":
        if resolved_raw:
            ok_res, res_val, err_res = validate_iso_date(
                resolved_raw,
                "Resolved date",
                min_date=rep_date_val if ok_rep_date else None,
            )
            if ok_res:
                cleaned["resolved_date"] = res_val
            else:
                errors["resolved_date"] = err_res
        else:
            cleaned["resolved_date"] = date.today().isoformat()
    else:
        cleaned["resolved_date"] = None

    return len(errors) == 0, cleaned, errors


# --- Interactive Terminal Input Wrappers ---

def prompt_validated(
    prompt_text: str,
    validator: Callable[[str], Tuple[bool, Any, str]],
    input_fn: Callable[[str], str] = input,
    print_fn: Callable[[str], None] = print,
    default: Optional[str] = None,
) -> Any:
    """Loop until user terminal input satisfies the validator."""
    while True:
        suffix = f" [{default}]" if default is not None else ""
        raw = input_fn(f"{prompt_text}{suffix}: ")
        if not raw.strip() and default is not None:
            raw = default
        ok, value, error = validator(raw)
        if ok:
            return value
        print_fn(f"  [Validation Error] {error}")


def prompt_choice(
    prompt_text: str,
    options: Sequence[str],
    input_fn: Callable[[str], str] = input,
    print_fn: Callable[[str], None] = print,
    default: Optional[str] = None,
) -> str:
    """Prompt user to pick either by number (1..N) or exact option name."""
    print_fn(f"  Options: " + ", ".join(f"{idx}. {opt}" for idx, opt in enumerate(options, 1)))
    while True:
        suffix = f" [{default}]" if default else ""
        raw = input_fn(f"{prompt_text}{suffix}: ").strip()
        if not raw and default:
            raw = default
        if raw.isdigit():
            idx = int(raw)
            if 1 <= idx <= len(options):
                return options[idx - 1]
            print_fn(f"  [Validation Error] Enter a number between 1 and {len(options)}.")
            continue
        ok, value, error = validate_choice(raw, options, prompt_text)
        if ok:
            return value
        print_fn(f"  [Validation Error] {error}")


def format_validation_errors(errors: Dict[str, str]) -> List[str]:
    """Format field error mapping into human-readable lines."""
    return [f"{field}: {msg}" for field, msg in errors.items()]
