import express from 'express';
import { spawn } from 'node:child_process';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = 3000;

interface BridgeResponse {
  ok: boolean;
  [key: string]: unknown;
}

function runPythonBridge(action: string, payload: unknown = {}): Promise<BridgeResponse> {
  return new Promise((resolve, reject) => {
    const child = spawn('python3', ['-m', 'hostel_tracker.bridge', action], {
      cwd: __dirname,
      stdio: ['pipe', 'pipe', 'pipe'],
    });

    let stdout = '';
    let stderr = '';

    child.stdout.on('data', (chunk: Buffer) => {
      stdout += chunk.toString('utf8');
    });

    child.stderr.on('data', (chunk: Buffer) => {
      stderr += chunk.toString('utf8');
    });

    child.on('error', (err) => {
      reject(new Error(`Failed to invoke python3 bridge: ${err.message}`));
    });

    child.on('close', (code) => {
      if (code !== 0 && !stdout.trim()) {
        reject(new Error(`Python bridge exited with code ${code}: ${stderr.trim()}`));
        return;
      }
      try {
        const parsed = JSON.parse(stdout) as BridgeResponse;
        resolve(parsed);
      } catch (err) {
        reject(
          new Error(
            `Invalid JSON from python3 bridge (${(err as Error).message}): ${stdout.slice(0, 300)}`
          )
        );
      }
    });

    child.stdin.write(JSON.stringify(payload));
    child.stdin.end();
  });
}

async function createServer() {
  const app = express();
  app.use(express.json({ limit: '2mb' }));

  app.get('/api/state', async (req, res) => {
    try {
      const payload = {
        keyword: typeof req.query.keyword === 'string' ? req.query.keyword : '',
        category: typeof req.query.category === 'string' ? req.query.category : 'All',
        block: typeof req.query.block === 'string' ? req.query.block : 'All',
        status: typeof req.query.status === 'string' ? req.query.status : 'All',
        priority: typeof req.query.priority === 'string' ? req.query.priority : 'All',
        overdue_only: req.query.overdue_only === 'true',
      };
      const result = await runPythonBridge('state', payload);
      res.json(result);
    } catch (err) {
      res.status(500).json({ ok: false, error: (err as Error).message });
    }
  });

  app.post('/api/requests', async (req, res) => {
    try {
      const result = await runPythonBridge('register', req.body ?? {});
      if (!result.ok) {
        res.status(400).json(result);
        return;
      }
      res.status(201).json(result);
    } catch (err) {
      res.status(500).json({ ok: false, error: (err as Error).message });
    }
  });

  app.patch('/api/requests/:id/status', async (req, res) => {
    try {
      const result = await runPythonBridge('update_status', {
        request_id: req.params.id,
        status: req.body?.status,
        assigned_staff: req.body?.assigned_staff,
        notes: req.body?.notes,
      });
      if (!result.ok) {
        res.status(400).json(result);
        return;
      }
      res.json(result);
    } catch (err) {
      res.status(500).json({ ok: false, error: (err as Error).message });
    }
  });

  app.post('/api/import', async (req, res) => {
    try {
      const csvText = typeof req.body?.csv_text === 'string' ? req.body.csv_text : '';
      const result = await runPythonBridge('import_csv', { csv_text: csvText });
      res.json(result);
    } catch (err) {
      res.status(500).json({ ok: false, error: (err as Error).message });
    }
  });

  app.get('/api/export', async (req, res) => {
    try {
      const format = typeof req.query.format === 'string' ? req.query.format : 'md';
      const result = await runPythonBridge('export', { format });
      if (!result.ok) {
        res.status(400).json(result);
        return;
      }
      res.json(result);
    } catch (err) {
      res.status(500).json({ ok: false, error: (err as Error).message });
    }
  });

  app.get('/api/sample-import-csv', async (_req, res) => {
    try {
      const csvPath = path.join(__dirname, 'data', 'legacy_import_sample.csv');
      const content = await fs.readFile(csvPath, 'utf8');
      res.json({ ok: true, content });
    } catch (err) {
      res.status(500).json({ ok: false, error: (err as Error).message });
    }
  });

  app.post('/api/terminal', async (req, res) => {
    try {
      const command = typeof req.body?.command === 'string' ? req.body.command : 'menu';
      const result = await runPythonBridge('terminal', { command });
      res.json(result);
    } catch (err) {
      res.status(500).json({ ok: false, error: (err as Error).message });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Hostel Maintenance Tracker server listening on http://0.0.0.0:${PORT}`);
  });
}

createServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
